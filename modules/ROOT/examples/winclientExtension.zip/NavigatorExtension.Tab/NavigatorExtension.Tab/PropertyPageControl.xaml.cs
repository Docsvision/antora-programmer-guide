﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.ObjectModel.Mapping;
using DocsVision.BackOffice.ObjectModel.Services;
using DocsVision.Platform.CardHost;
using DocsVision.Platform.Data.Metadata;
using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;
using DocsVision.Platform.ObjectModel.Persistence;
using DocsVision.Platform.SystemCards.ObjectModel.Mapping;
using DocsVision.Platform.SystemCards.ObjectModel.Services;
using DocsVision.Platform.Wpf;
using System;
using System.Runtime.InteropServices;
using System.Windows;

namespace NavigatorExtension.Tab
{
    /// <summary>
    /// Interaction logic for PropertyPageControl.xaml
    /// </summary>
    [ComVisible(true)]
    [Guid("95821EC8-34C2-4914-A4C2-125D1BF6FFDE")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class PropertyPageControl : NavPropertyPageControl
    {
        /// <summary>
        /// Параметры активации страницы:
        ///  ReadOnly - только чтение
        ///  CardData - данные карточки
		///  CardID - идентификатор карточки
		///  CardTypeID - идентификатор типа карточки
		///  CardDesc - дайджест карточки
		///  FolderID - идентификатор папки
	    ///  ShortcutID - идентификатор ярлыка
		///  Archived - признак архивной карточки
		///  Template - признак карточки-шаблона
		///  CreateDate - дата создания
		///  ChangeDate - дата изменения
        /// </summary>
        private ParameterCollection activateParams
        {
            get { return this.ActivateParams as ParameterCollection; }
        }

        // Задача, для которой открывается карточка
        Task BaseObject
        {
            get
            {
                try
                {
                    Task task = ObjectContext.GetObject<Task>(Guid.Parse(activateParams["CardID"].ToString()));
                    return task;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return null;
            }
        }

        ObjectContext ObjectContext;
        IStaffService StaffService;
        ITaskService TaskService;
        IStateService StateService;

        public PropertyPageControl() { }

        /// <summary>
        /// Правильная инициализация страницы свойств
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPageInitialized(EventArgs e)
        {
            if (Guid.Parse(activateParams["CardTypeID"].ToString()) != DocsVision.BackOffice.CardLib.CardDefs.CardTask.ID)
            {
                throw new Exception("Несоотвествие типа карточки");
            }
            ObjectContextCreate();
            base.OnPageInitialized(e);
            InitializeComponent();
            PostInit();
        }

        /// <summary>
        /// Создаем контекст объектов
        /// </summary>
        private void ObjectContextCreate()
        {
            var sessionContainer = new System.ComponentModel.Design.ServiceContainer();
            sessionContainer.AddService(typeof(DocsVision.Platform.ObjectManager.UserSession), this.Session);

            ObjectContext = new ObjectContext(sessionContainer);
            var mapperFactoryRegistry = ObjectContext.GetService<IObjectMapperFactoryRegistry>();
            mapperFactoryRegistry.RegisterFactory(typeof(SystemCardsMapperFactory));
            mapperFactoryRegistry.RegisterFactory(typeof(BackOfficeMapperFactory));


            var serviceFactoryRegistry = ObjectContext.GetService<IServiceFactoryRegistry>();
            serviceFactoryRegistry.RegisterFactory(typeof(SystemCardsServiceFactory));
            serviceFactoryRegistry.RegisterFactory(typeof(BackOfficeServiceFactory));

            ObjectContext.AddService<IPersistentStore>(DocsVisionObjectFactory.CreatePersistentStore(new SessionProvider(this.Session), null));

            IMetadataProvider metadataProvider = DocsVisionObjectFactory.CreateMetadataProvider(this.Session);
            ObjectContext.AddService<IMetadataManager>(DocsVisionObjectFactory.CreateMetadataManager(metadataProvider, this.Session));
            ObjectContext.AddService<IMetadataProvider>(metadataProvider);


            StaffService = ObjectContext.GetService<IStaffService>();
            TaskService = ObjectContext.GetService<ITaskService>();
            StateService = ObjectContext.GetService<IStateService>();
        }

        /// <summary>
        /// Передаем информацию о задании для отображения пользователю
        /// </summary>
        private void PostInit()
        {
            TaskName.Content = BaseObject.MainInfo.Name;

            switch (BaseObject.MainInfo.Priority)
            {
                case DocsVision.BackOffice.ObjectModel.TaskPriority.High:
                    TaskPriority.Content = "Высокий";
                    break;
                case DocsVision.BackOffice.ObjectModel.TaskPriority.Low:
                    TaskPriority.Content = "Низкий";
                    break;
                default:
                    TaskPriority.Content = "Нормальный";
                    break;
            }

            TaskState.Content = BaseObject.SystemInfo.State.LocalizedName;
            TaskAuthor.Content = BaseObject.MainInfo.Author.DisplayName;
            TaskEndDateActual.Content = BaseObject.MainInfo.EndDate.HasValue ? BaseObject.MainInfo.EndDate.Value.ToString("dd.MM.yyyy") : string.Empty;
            TaskContent.Content = BaseObject.MainInfo.Content;
        }
    }
}
