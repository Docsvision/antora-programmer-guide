﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.ObjectModel.Mapping;
using DocsVision.BackOffice.ObjectModel.Services;
using DocsVision.Platform.CardHost;
using DocsVision.Platform.Data.Metadata;
using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;
using DocsVision.Platform.ObjectModel.Persistence;
using DocsVision.Platform.SystemCards.ObjectModel.Mapping;
using DocsVision.Platform.SystemCards.ObjectModel.Services;
using DocsVision.Platform.WinForms;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Linq;


namespace NavigatorExtension.Tab
{
    [ComVisible(true)]
    [Guid("5A88A509-E8F1-438F-9E93-BE40371D3FBD")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class PropertyPage : NavPropertyPageControl
    {
        // Параметры активации, из которых можно получить идентификатор карточки, для которой вызвано контекстное меню
        /*
         ReadOnly - только чтение
		 CardData - данные карточки
		 CardID - идентификатор карточки
		 CardTypeID - идентификатор типа карточки
		 CardDesc - дайджест карточки
		 FolderID - идентификатор папки
	     ShortcutID - идентификатор ярлыка
		 Archived - признак архивирования
		 Template - шаблон
		 CreateDate - дата создания
		 ChangeDate - дата изменения
         */
        private ParameterCollection activateParams
        {
            get { return this.ActivateParams as ParameterCollection; }
        }

        // Задача, для которой открывается карточка
        Task BaseObject
        {
            get
            {
                try
                {
                    Task task = ObjectContext.GetObject<Task>(Guid.Parse(activateParams["CardID"].ToString()));
                    return task;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return null;
            }
        }

        ObjectContext ObjectContext;
        IStaffService StaffService;
        ITaskService TaskService;
        IStateService StateService;

        public PropertyPage() { }

        /// <summary>
        /// Правильная инициализация страницы свойств
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPageInitialized(EventArgs e)
        {
            if (Guid.Parse(activateParams["CardTypeID"].ToString()) != DocsVision.BackOffice.CardLib.CardDefs.CardTask.ID)
            {
                this.Controls.Clear();

                Label unavailable = new Label();
                unavailable.Text = "Недоступно для данного типа карточек";
                unavailable.AutoSize = true;
                unavailable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;

                this.Controls.Add(unavailable);
                return;
            }

            ObjectContextCreate();

            base.OnPageInitialized(e);
            InitializeComponent();
            PostInit();
        }

        protected override void OnPageApplied(EventArgs e)
        {
            //BaseObject.MainInfo.Name = TaskName.Text;
            //ObjectContext.SaveObject(BaseObject);

            base.OnPageApplied(e);
        }

        private void ObjectContextCreate()
        {
            var sessionContainer = new System.ComponentModel.Design.ServiceContainer();
            sessionContainer.AddService(typeof(DocsVision.Platform.ObjectManager.UserSession), this.Session);

            ObjectContext = new ObjectContext(sessionContainer);
            var mapperFactoryRegistry = ObjectContext.GetService<IObjectMapperFactoryRegistry>();
            mapperFactoryRegistry.RegisterFactory(typeof(SystemCardsMapperFactory));
            mapperFactoryRegistry.RegisterFactory(typeof(BackOfficeMapperFactory));


            var serviceFactoryRegistry = ObjectContext.GetService<IServiceFactoryRegistry>();
            serviceFactoryRegistry.RegisterFactory(typeof(SystemCardsServiceFactory));
            serviceFactoryRegistry.RegisterFactory(typeof(BackOfficeServiceFactory));

            ObjectContext.AddService<IPersistentStore>(DocsVisionObjectFactory.CreatePersistentStore(new SessionProvider(this.Session), null));

            IMetadataProvider metadataProvider = DocsVisionObjectFactory.CreateMetadataProvider(this.Session);
            ObjectContext.AddService<IMetadataManager>(DocsVisionObjectFactory.CreateMetadataManager(metadataProvider, this.Session));
            ObjectContext.AddService<IMetadataProvider>(metadataProvider);



            StaffService = ObjectContext.GetService<IStaffService>();
            TaskService = ObjectContext.GetService<ITaskService>();
            StateService = ObjectContext.GetService<IStateService>();
        }

        private void PostInit()
        {
            //TaskName.Text = BaseObject.MainInfo.Name;
            taskAuthor.Text = BaseObject.MainInfo.Author.DisplayName;
            taskEndDateActual.Text = BaseObject.MainInfo.EndDate.HasValue ? BaseObject.MainInfo.EndDate.Value.ToString("dd.MM.yyyy") : string.Empty;
            taskContent.Text = BaseObject.MainInfo.Content;

            try
            {
                simpleButton1.Text = string.Format("Делегировать заместителю ({0})", StaffService.GetCurrentEmployee().Deputies.First().Employee.DisplayName);
            }
            catch (Exception ex) { MessageBox.Show("Рано, т.к. " + ex.Message); }
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }


        private void button2_Click(object sender, EventArgs e)
        {
            // Завершить
            IStaffService staffservice = (IStaffService)base.GetService(typeof(IStaffService));
            MessageBox.Show(staffservice.GetCurrentEmployee().DisplayName);
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            // Получение сотрудника, которому осуществляется делегирование задания
            StaffEmployee newPerformer = StaffService.GetCurrentEmployee().Deputies.First().Employee;

            // Делегирование задания сотруднику newPerformer
            TaskService.Delegate(BaseObject, new StaffEmployee[] { newPerformer },
                null, false, false, "Было выполнено ленивое делегирование");

            // Установка для задания состояния Делегировано
            StateService.ChangeState(BaseObject, StateService.FindStateByBuiltIn(Task.DelegatedState, BaseObject));

            MessageBox.Show(string.Format("{0} делегировано.", BaseObject.MainInfo.Name));
        }


    }
}
