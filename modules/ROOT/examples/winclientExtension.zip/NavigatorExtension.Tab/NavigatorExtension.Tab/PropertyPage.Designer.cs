﻿namespace NavigatorExtension.Tab
{
    partial class PropertyPage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelAuthor = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.taskAuthor = new DevExpress.XtraEditors.LabelControl();
            this.taskEndDateActual = new DevExpress.XtraEditors.LabelControl();
            this.taskContent = new DevExpress.XtraEditors.MemoEdit();
            ((System.ComponentModel.ISupportInitialize)(this.taskContent.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // labelAuthor
            // 
            this.labelAuthor.Location = new System.Drawing.Point(18, 12);
            this.labelAuthor.Name = "labelAuthor";
            this.labelAuthor.Size = new System.Drawing.Size(80, 13);
            this.labelAuthor.TabIndex = 2;
            this.labelAuthor.Text = "Автор задания:";
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(18, 187);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(248, 23);
            this.simpleButton1.TabIndex = 3;
            this.simpleButton1.Text = "Делегирование";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(18, 40);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(91, 13);
            this.labelControl1.TabIndex = 4;
            this.labelControl1.Text = "Срок исполнения:";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(18, 75);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(68, 13);
            this.labelControl2.TabIndex = 5;
            this.labelControl2.Text = "Содержание:";
            // 
            // taskAuthor
            // 
            this.taskAuthor.Location = new System.Drawing.Point(153, 12);
            this.taskAuthor.Name = "taskAuthor";
            this.taskAuthor.Size = new System.Drawing.Size(32, 13);
            this.taskAuthor.TabIndex = 6;
            this.taskAuthor.Text = "author";
            // 
            // taskEndDateActual
            // 
            this.taskEndDateActual.Location = new System.Drawing.Point(153, 40);
            this.taskEndDateActual.Name = "taskEndDateActual";
            this.taskEndDateActual.Size = new System.Drawing.Size(71, 13);
            this.taskEndDateActual.TabIndex = 7;
            this.taskEndDateActual.Text = "endDateActual";
            // 
            // taskContent
            // 
            this.taskContent.Location = new System.Drawing.Point(18, 94);
            this.taskContent.Name = "taskContent";
            this.taskContent.Properties.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.taskContent.Size = new System.Drawing.Size(354, 87);
            this.taskContent.TabIndex = 8;
            this.taskContent.UseOptimizedRendering = true;
            // 
            // PropertyPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.taskContent);
            this.Controls.Add(this.taskEndDateActual);
            this.Controls.Add(this.taskAuthor);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.labelAuthor);
            this.Name = "PropertyPage";
            this.Size = new System.Drawing.Size(403, 274);
            ((System.ComponentModel.ISupportInitialize)(this.taskContent.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.LabelControl labelAuthor;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl taskAuthor;
        private DevExpress.XtraEditors.LabelControl taskEndDateActual;
        private DevExpress.XtraEditors.MemoEdit taskContent;
    }
}
