﻿using DocsVision.Platform.Extensibility;
using DocsVision.Platform.Wpf;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace NavigatorExtension.Tab
{
    /// <summary>
    /// Interaction logic for Extension.xaml
    /// </summary>
    [ComVisible(true)]
    [Guid("4A8331EC-9E4E-4E26-91A4-8E621D39870D")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class Extension : NavExtension
    {
        public Extension()
        {
        }

        // Предпочтительный способ инициализации расширения
        protected override void OnCardInitialized(EventArgs e)
        {
            InitializeComponent();
            base.OnCardInitialized(e);
        }

        /// <summary>
        ///  Название расширения
        /// </summary>
        /// <param name="extensionType">В зависимости от запрашиваемого типа можно вернуть расзные названия</param>
        /// <returns></returns>
        protected override string GetExtensionName(NavExtensionTypes extensionType)
        {
            return "Расширение 'Страница свойств'";
        }

        /// <summary>
        /// Тип расширения (тиы, подерживаемые расширением: свойства, команды ленты и т.д.)
        /// </summary>
        protected override NavExtensionTypes SupportedTypes
        {
            get
            {
                return NavExtensionTypes.PropertyPages;
            }
        }

        /// <summary>
        /// Предоставляем дополнительные страницы свойств
        /// </summary>
        /// <returns></returns>
        protected override IEnumerable<NavPropertyPage> CreatePropertyPages()
        {
            // Страницы, предоставляемые расширением
            return new NavPropertyPage[] { 
                new NavPropertyPage() {
                    PageType = NavPropertyPageTypes.All,
                    Name = "Информация о задании",
                    Clsid = typeof(PropertyPageControl).GUID
                }
            };
        }
    }
}
