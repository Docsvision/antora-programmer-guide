﻿using DocsVision.BackOffice.ObjectModel.Mapping;
using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;

namespace NetstatSolutionCard.ObjectModel.Mappers
{
    public class NetstatSolutionCardJournalMapper : BaseCardSectionRowMapper<NetstatSolutionCardJournal>
    {
        private static ObjectMap map;
		static NetstatSolutionCardJournalMapper()
		{
			NetstatSolutionCardJournalMapper.InitializeObjectMap();
		}
        public NetstatSolutionCardJournalMapper(ObjectContext context)
            : base(context)
		{
		}
		protected override ObjectMap GetObjectMap()
		{
            return NetstatSolutionCardJournalMapper.map;
		}
        protected override NetstatSolutionCardJournal CreateObject(ObjectInitializationData data)
		{
            return new NetstatSolutionCardJournal(data);
		}
		private static void InitializeObjectMap()
		{
            NetstatSolutionCardJournalMapper.map = new ObjectMap();
            NetstatSolutionCardJournalMapper.map.ObjectTypeId = NetstatSolutionCardDefs.Journal.ID;
            NetstatSolutionCardJournalMapper.map.Field(NetstatSolutionCardJournal.DateProperty, "Date");
            NetstatSolutionCardJournalMapper.map.Field(NetstatSolutionCardJournal.ResultProperty, "Result");
		}
    }
}
