﻿using DocsVision.BackOffice.ObjectModel.Mapping;
using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetstatSolutionCard.ObjectModel.Mappers
{
    public class NetstatSolutionCardMainInfoMapper : BaseCardSectionRowMapper<NetstatSolutionCardMainInfo>
    {
        private static ObjectMap map;
		static NetstatSolutionCardMainInfoMapper()
		{
			NetstatSolutionCardMainInfoMapper.InitializeObjectMap();
		}
        public NetstatSolutionCardMainInfoMapper(ObjectContext context)
            : base(context)
		{
		}
		protected override ObjectMap GetObjectMap()
		{
            return NetstatSolutionCardMainInfoMapper.map;
		}
        protected override NetstatSolutionCardMainInfo CreateObject(ObjectInitializationData data)
		{
            return new NetstatSolutionCardMainInfo(data);
		}
		private static void InitializeObjectMap()
		{
            NetstatSolutionCardMainInfoMapper.map = new ObjectMap();
            NetstatSolutionCardMainInfoMapper.map.ObjectTypeId = NetstatSolutionCardDefs.MainInfo.ID;
            NetstatSolutionCardMainInfoMapper.map.Field(NetstatSolutionCardMainInfo.AddressProperty, "Address");
            NetstatSolutionCardMainInfoMapper.map.Field(NetstatSolutionCardMainInfo.IsCheckedProperty, "IsChecked");
            NetstatSolutionCardMainInfoMapper.map.Field(NetstatSolutionCardMainInfo.LastResultProperty, "LastResult");
            NetstatSolutionCardMainInfoMapper.map.Field(NetstatSolutionCardMainInfo.NameProperty, "Name");
            NetstatSolutionCardMainInfoMapper.map.Field(NetstatSolutionCardMainInfo.TypeProperty, "Type");
		}
    }
}
