﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetstatSolution.Snapin
{
    public class Common
    {
        public const string NetstatSolutionKey = "Software\\DocsVision\\NetstatSolution\\5.0";
        public const string EmailAdminRegName = "EmailAdmin";
        public const string CheckIsEnabledRegName = "CheckIsEnabled";
        public const string LicenseRegName = "License";

        public static Microsoft.Win32.RegistryKey GetSubKey(Microsoft.Win32.RegistryKey parent, string subKey)
        {
            Microsoft.Win32.RegistryKey result = null;

            try
            {
                result = parent.CreateSubKey(subKey);
            }
            catch { }

            if (result == null)
            {
                try
                {
                    result = parent.OpenSubKey(subKey, true);
                }
                catch { }

                if (result == null)
                {
                    try
                    {
                        result = parent.OpenSubKey(subKey, false);
                    }
                    catch { }

                    if (result == null)
                    {
                        System.Windows.Forms.MessageBox.Show(string.Format("Ошибка создания ключа реестра: {0}\\{1}", parent.Name, subKey));
                    }
                }
            }

            return result;
        }
    }
}
