﻿namespace NetstatSolution.Snapin
{
    partial class SnapInForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Admin_eMail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CheckIsOn = new System.Windows.Forms.CheckBox();
            this.License = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Admin_eMail
            // 
            this.Admin_eMail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Admin_eMail.Location = new System.Drawing.Point(147, 15);
            this.Admin_eMail.Name = "Admin_eMail";
            this.Admin_eMail.Size = new System.Drawing.Size(332, 20);
            this.Admin_eMail.TabIndex = 0;
            this.Admin_eMail.TextChanged += new System.EventHandler(this.Admin_eMail_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "e-mail администратора";
            // 
            // CheckIsOn
            // 
            this.CheckIsOn.AutoSize = true;
            this.CheckIsOn.Checked = true;
            this.CheckIsOn.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckIsOn.Location = new System.Drawing.Point(6, 73);
            this.CheckIsOn.Name = "CheckIsOn";
            this.CheckIsOn.Size = new System.Drawing.Size(128, 17);
            this.CheckIsOn.TabIndex = 2;
            this.CheckIsOn.Text = "Проверка включена";
            this.CheckIsOn.UseVisualStyleBackColor = true;
            this.CheckIsOn.CheckedChanged += new System.EventHandler(this.CheckIsOn_CheckedChanged);
            // 
            // License
            // 
            this.License.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.License.Location = new System.Drawing.Point(147, 41);
            this.License.Name = "License";
            this.License.Size = new System.Drawing.Size(332, 20);
            this.License.TabIndex = 3;
            this.License.TextChanged += new System.EventHandler(this.License_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Лицензионный ключ";
            // 
            // SnapInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.License);
            this.Controls.Add(this.CheckIsOn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Admin_eMail);
            this.Name = "SnapInForm";
            this.Size = new System.Drawing.Size(482, 104);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Admin_eMail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox CheckIsOn;
        private System.Windows.Forms.TextBox License;
        private System.Windows.Forms.Label label2;
    }
}
