﻿using DocsVision.Platform.StorageServer.BinaryStorages.Rules;
using DocsVision.Platform.StorageServer.Files;
using System;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace RuleByFileName
{
    [DisplayName("Шаблон файла")]
    [Editor(
        "RuleByFileName.FileNamePatternPropertyControl, RuleByFileName, Version=1.0.0.0, Culture=neutral, PublicKeyToken=774759c67c4f8865, processorArchitecture=MSIL"
        , "DocsVision.Platform.WinForms.Controls.IExtensionPropertiesControl, DocsVision.Platform.WinForms"
    )]
    public class FileNameStorageRule : BaseBinaryStorageRule
    {
        string fileNamePattern;

        public FileNameStorageRule()
        {
        }

        public FileNameStorageRule(IServiceProvider serviceProvider) : base(serviceProvider, null)
        {
        }
               
        public override bool IsRuleSatisfied(IFileInfo fileInfo)
        {
            Regex regex = new Regex(fileNamePattern, RegexOptions.IgnoreCase);
            return regex.IsMatch(fileInfo.Name);
        }

        protected override void ReadSettings()
        {
            fileNamePattern = Settings.Replace(@"\", @"\\").Replace(".", @"\.").Replace("*", ".*");
            fileNamePattern = "^" + fileNamePattern + "$";
        }
    }
}
