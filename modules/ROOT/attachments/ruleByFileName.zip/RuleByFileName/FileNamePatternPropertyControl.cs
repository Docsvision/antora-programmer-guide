﻿using DocsVision.Platform.WinForms.Controls;
using System;
using System.Windows.Forms;

namespace RuleByFileName
{
    public partial class FileNamePatternPropertyControl : UserControl, IExtensionPropertiesControl
    {
       
        public FileNamePatternPropertyControl()
        {
            InitializeComponent();
        }

        public string Settings
        {
            get;
            private set;
        }

        public event EventHandler OnPropertiesChanged;

        // Вызывается при загрузке компонента 
        public void Initialize(string settings)
        {
            Settings = settings ?? "*.*";

            PatternBox.Text = Settings;
        }

        // Вызывается при сохранении настроек
        public bool Save()
        {
            Settings = PatternBox.Text;
            return true;
        }

        private void PatternBox_TextChanged(object sender, EventArgs e)
        {
            OnPropertiesChanged?.Invoke(this, e);
        }
    }
}
