﻿using DocsVision.Platform.Extensibility;
using DocsVision.Platform.ObjectManager;
using DocsVision.Platform.ObjectManager.Metadata;
using DocsVision.Platform.ObjectManager.SearchModel;
using DocsVision.Platform.WinForms;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Docsvision.Samples.NavigatorPlugin
{
    [ComVisible(true)]
    [Guid("6A0676EE-1DAF-4A59-B5EB-E0B5B4C175E1")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class Plugin : NavExtension
    {
        public Plugin() { }

        // Тип расширения
        protected override NavExtensionTypes SupportedTypes
        {
            get
            {
                return NavExtensionTypes.Command;
            }
        }

        // Название расширения
        protected override string GetExtensionName(NavExtensionTypes extensionType)
        {
            return "Быстрый выбор";
        }

        // Инициализация списка команд
        protected override IEnumerable<NavCommand> CreateCommands()
        {
            NavCommand myCommand = new NavCommand();
            myCommand.CommandType = NavCommandTypes.ToolBar; // В данном случае - команда размещается на ленте инструментов
            myCommand.Name = "Выбрать папку";
            myCommand.Description = "Команда выбирает заданную папку";
            myCommand.Location = new NavCommandLocation()
            {
                RibbonTabLocations = new RibbonTabLocation[]
                { 
                 new RibbonTabLocation
                 {
                  Tab = "Доп. команды",
                  Groups = new string[] { "Группы" }
                 }
                }
            };
            return new List<NavCommand> { myCommand };
        }

        // Проверка команды на доступность 
        protected override NavCommandStatus QueryCommandStatus(NavCommand command, NavCommandContext context)
        {
            return NavCommandStatus.Enabled; // всегда доступна
        }

        // Непосредственное исполнение команды расширения
        protected override void InvokeCommand(NavCommand command, NavCommandContext context)
        {
            string accountName = base.Session.Properties["AccountName"].Value.ToString();

            // Идентификаторы Справочника сотрудников и секции Сотрудники
            Guid RefStaff = new Guid("6710B92A-E148-4363-8A6F-1AA0EB18936C");
            Guid Employees = new Guid("DBC8AE9D-C1D2-4D5E-978B-339D22B32482");

            // Поиск в секции Сотрудники сотрудника с учетной записью accountName (учетная запись текущего сотрудника)
            SectionQuery sectionQuery = base.Session.CreateSectionQuery();
            sectionQuery.ConditionGroup.Conditions.AddNew("AccountName", FieldType.String, ConditionOperation.Equals, accountName);

            CardData staffData = base.Session.CardManager.GetDictionaryData(RefStaff, false);
            RowDataCollection users = staffData.Sections[Employees].FindRows(sectionQuery.GetXml());

            if (users.Count > 0)
            {

                // Получение Личной папки
                Guid? personalFolderID = users[0].GetGuid("PersonalFolder");
                if (personalFolderID.HasValue)
                {

                    // Установка курсора на папку
                    CardFrame.CardHost.ActivateFolder(personalFolderID.Value, true);
                }
            }
        }
    }
}