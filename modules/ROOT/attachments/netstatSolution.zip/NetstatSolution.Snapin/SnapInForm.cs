﻿using DocsVision.Tools.ServerConsole;
using Microsoft.Win32;
using System;
using System.Windows.Forms;

namespace NetstatSolution.Snapin
{
    public partial class SnapInForm : UserControl, IConsoleControl
    {
        bool isChanged;

        // Экземпляр создается при открытии Консоли управления
        public SnapInForm()
        {
            InitializeComponent();
        }

        // Возвращает признак наличия изменений
        public bool Changed
        {
            set
            {
                isChanged = value;
                ControlChanged();
            }
            get
            {
                return isChanged;
            }
        }

        public event ControlChangedDelegate ControlChanged;

        // Возвращает признак корректности введенных данных
        public bool Valid
        {
            get
            {
                bool result = true;
                if (Admin_eMail.Text.Contains("@") == false)
                {
                    result = false;
                }
                return result;
            }
        }


        // Задает название формы редактирования в меню Консоли управления
        public string Caption
        {
            get { return "Модуль учета сетевых устройств"; }
        }

        // Возвращает ссылку на экземпляр данной формы 
        public UserControl Instance
        {
            get { return this; }
        }

        // Метод вызывается при сохранении данных формы ввода
        public bool Execute()
        {
            try
            {
                using (RegistryKey key = Common.GetSubKey(Registry.LocalMachine, Common.NetstatSolutionKey))
                {
                    key.SetValue(Common.EmailAdminRegName, Admin_eMail.Text);
                    key.SetValue(Common.CheckIsEnabledRegName, Convert.ToInt32(CheckIsOn.Checked));
                    key.SetValue(Common.LicenseRegName, License.Text);
                }
                isChanged = false;
            }
            catch
            {
                return false;
            }
            return true;
        }

        // Метод вызывается при открытии формы
        public void Initialize()
        {
            try
            {
                using (RegistryKey key = Common.GetSubKey(Registry.LocalMachine, Common.NetstatSolutionKey))
                {
                    Admin_eMail.Text = key.GetValue(Common.EmailAdminRegName, string.Empty).ToString();
                    CheckIsOn.Checked = Convert.ToBoolean((int)key.GetValue(Common.CheckIsEnabledRegName, 1));
                    License.Text = key.GetValue(Common.LicenseRegName, string.Empty).ToString();
                }
            }
            catch { }
            isChanged = false;
        }

        private void CheckIsOn_CheckedChanged(object sender, EventArgs e)
        {
            Changed = true;
        }

        private void Admin_eMail_TextChanged(object sender, EventArgs e)
        {
            Changed = true;
        }

        private void License_TextChanged(object sender, EventArgs e)
        {
            Changed = true;
        }
    }
}
