﻿using DocsVision.Tools.ServerConsole;
using Microsoft.Win32;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace NetstatSolution.Snapin
{
    public class SnapIn : ISnapIn, IConfigurator, IUninstallSnapIn, IDBInformation
    {
        private IEnvironment _environment;

        // Получение пути к сборке для работы с относительными путями
        private string AssemblyFolder
        {
            get
            {
                string path = Uri.UnescapeDataString(new UriBuilder(Assembly.GetExecutingAssembly().CodeBase).Path);
                return Path.GetDirectoryName(path);
            }
        }


        #region Реализация интефейса ISnapIn

        // Возвращает идентификатор библиотеки карточек
        public string LibraryID
        {
            get { return "{F729F178-15DA-4BDE-82B8-DD0B2F0C0BC6}"; } //задать правильный идентификатор библиотеки
        }

        // Возвращает отображаемое название модуля
        public string Name
        {
            get { return "Консоль управления Модуля учета сетевых устройств"; }
        }

        // Выполняет инициализацию модуля расширения. Позволяет получить переменные окружения
        public void Initialize(IEnvironment environment)
        {
            _environment = environment;
        }

        // Возвращает интерфейс управления решением для различных режимов запуска Консоли управления
        public object QueryInterface(SnapInInterfacesEnum itf)
        {
            object result = null;

            switch (itf)
            {
                case SnapInInterfacesEnum.CONFIGURATOR: // Первичная инсталляция решения
                case SnapInInterfacesEnum.UNINSTALL_SNAP_IN: // Деинсталляция решения
                case SnapInInterfacesEnum.DB_INFORMATION: //
                    result = this;
                    break;

                case SnapInInterfacesEnum.CONSOLE_CONTROL: // Режим администрирования
                    result = new SnapInForm();
                    break;
            }

            return result;
        }
        #endregion

        #region Реализация интерфейса IConfigurator

        // Вызывается запуском процесса конфигурирования
        public bool Execute()
        {
            ILog log = (ILog)_environment.QueryService(EnvironmentServiceEnum.LOG);

            // Регистрация клиентского пакета установки
            ICardLibConfigurator2 cardLibConfig = (ICardLibConfigurator2)_environment.QueryService(EnvironmentServiceEnum.CARD_LIB_CONFIGURATOR);

            cardLibConfig.RegisterPackage(
                "E98E531F-D34C-41D6-9BCA-9972F46EB6DF", // Идентификатор пакета установки
                "22CE4047-0BA8-4014-9BBE-7D8C43FDE901", // Код продукта
                Path.Combine(AssemblyFolder, "NetstatSolutionClient.msi"));

            log.WriteMessage("Конфигурирование завершено");
            return true;
        }
        #endregion
        
        #region Реализация интерфейса IDBInformation

        // Определяет наличие в решении библиотеки карточек
        public bool ContainsCardLib
        {
            get { return true; }
        }
        
        // Возвращает путь к файлу – пакету инсталлируемых XML-описаний карточек
        public string GetCardPackage()
        {
            return Path.Combine(AssemblyFolder, "CardPackage\\CardPackage.xml");
        }

        // Возвращает путь с SQL-скриптам для загрузки в базу данных
        public string GetScript(ScriptTypeEnum type)
        {
            string result = string.Empty;

            switch (type)
            {
                case ScriptTypeEnum.INSTALL_TABLES:
                    result = Path.Combine(AssemblyFolder, "Database\\NetstatSolutionInstall.xml");
                    break;
            }

            return result;
        }

        #endregion

        #region Реализация интерфейса IUninstallSnapIn
        // Вызывается при удалении модуля
        public void Uninstall(bool removeSettings)
        {
            ILog log = (ILog)_environment.QueryService(EnvironmentServiceEnum.LOG);
            ICardLibConfigurator cardLibConfig = (ICardLibConfigurator)_environment.QueryService(EnvironmentServiceEnum.CARD_LIB_CONFIGURATOR);

            log.WriteMessage("Запущено удаление");

            cardLibConfig.RemoveCardLib(LibraryID);

            // Необходимо удалить настройки модуля
            if (removeSettings)
            {
                using (RegistryKey key = Common.GetSubKey(Registry.LocalMachine, Common.NetstatSolutionKey))
                {
                    key.DeleteValue(Common.EmailAdminRegName, false);
                    key.DeleteValue(Common.CheckIsEnabledRegName, false);
                    key.DeleteValue(Common.LicenseRegName, false);
                }
            }

            log.WriteMessage("Записи реестра удалены");
        }
        #endregion

    }
}
