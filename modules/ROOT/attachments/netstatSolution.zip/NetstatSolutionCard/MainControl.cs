﻿using DocsVision.BackOffice.WinForms;
using DocsVision.Platform.CardHost;
using System;
using System.Runtime.InteropServices;

namespace NetstatSolutionCard
{
    [ComVisible(true)]
    [Customizable(true)]
    [Guid("053B0CA1-95FD-4DDA-95FA-6043AFACCC1F")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class MainControl : DocsVision.BackOffice.WinForms.BaseCardControl
    {
        public MainControl()
        {
            // Проверка наличия и действительности решения
            if (!CheckLicense())
            {
                throw new Exception("Отсутствует лицензия для Модуля учета сетевых устройств");
            }
            InitializeComponent();
        }


        // Подлинность лицензии проверяется по значению ключа реестра, которое, для простоты, должно быть равно "ЛИЦЕНЗИЯ"
        private bool CheckLicense()
        {
            bool result = false;
            string trueLicenseKey = "ЛИЦЕНЗИЯ";

            try
            {
                string license = Microsoft.Win32.Registry.GetValue(Microsoft.Win32.Registry.LocalMachine + "Software\\DocsVision\\NetstatSolution\\5.0", "License", string.Empty).ToString();
                if (license == trueLicenseKey) result = true;
            }
            catch { }

            // Проверим ветку x64
            if (!result)
            {
                try
                {
                    Microsoft.Win32.RegistryKey HKLM64 = Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64);
                    string license = HKLM64.OpenSubKey("SOFTWARE\\DocsVision\\NetstatSolution\\5.0").GetValue("License", string.Empty).ToString();
                    if (license == trueLicenseKey) result = true;
                }
                catch { }
            }

            return result;
        }
    }
}
