﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetstatSolutionCard.Services
{
    public interface INetstatSolutionService
    {
        NetstatSolutionCard.ObjectModel.NetstatSolutionCard CreateCard(string name, string address, int type);
        ObjectModel.NetstatSolutionCardJournal AddJournalEntry(NetstatSolutionCard.ObjectModel.NetstatSolutionCard card, DateTime date, bool result);
    }
}
