﻿using DocsVision.BackOffice.ObjectModel.Services;
using DocsVision.Platform.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NetstatSolutionCard.Services
{
    internal class NetstatSolutionService : ContextService, INetstatSolutionService
    {
        IKindService KindService
        {
            get
            {
                return this.Context.GetService<IKindService>();
            }
        }
        IStateService StateService
        {
            get
            {
                return this.Context.GetService<IStateService>();
            }
        }

        public ObjectModel.NetstatSolutionCard CreateCard(string name, string address, int type)
        {
            ObjectModel.NetstatSolutionCard card = new ObjectModel.NetstatSolutionCard();
            card.MainInfo.Name = name;
            card.MainInfo.Address = address;
            card.MainInfo.Type = type;
            card.Description = string.Format("Узел {0}",name);

            // Для нормального открытия карточки, работающей с конструкторами необходимо установить вид карточки и её состояние
            card.SystemInfo.CardKind = this.KindService.GetCardType(NetstatSolutionCard.ObjectModel.NetstatSolutionCardDefs.ID).RootKind;
            card.SystemInfo.State = this.StateService.GetPreferredCardKindSetting(card.SystemInfo.CardKind).FirstState;

            base.Context.AddObject(card);
            return card;
        }

        public ObjectModel.NetstatSolutionCardJournal AddJournalEntry(ObjectModel.NetstatSolutionCard card, DateTime date, bool result)
        {
            NetstatSolutionCard.ObjectModel.NetstatSolutionCardJournal journalEntry = new NetstatSolutionCard.ObjectModel.NetstatSolutionCardJournal();
            journalEntry.Date = date;
            journalEntry.Result = result;

            if (card.Journal == null) 
                card.Journal = new ObjectCollection<ObjectModel.NetstatSolutionCardJournal>();
            card.Journal.Add(journalEntry);

            return journalEntry;
        }
    }
}
