﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.Platform.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetstatSolutionCard.ObjectModel
{
    public class NetstatSolutionCard : BaseCard
    {
        public static readonly ObjectProperty MainInfoProperty;
        public static readonly ObjectProperty JournalProperty;

        public NetstatSolutionCardMainInfo MainInfo
        {
            get
            {
                if (((ObjectCollection<NetstatSolutionCardMainInfo>)base.GetValue(NetstatSolutionCard.MainInfoProperty)).Count == 0)
                {
                    ((ObjectCollection<NetstatSolutionCardMainInfo>)base.GetValue(NetstatSolutionCard.MainInfoProperty)).Add(new NetstatSolutionCardMainInfo());
                }
                return ((ObjectCollection<NetstatSolutionCardMainInfo>)base.GetValue(NetstatSolutionCard.MainInfoProperty)).First<NetstatSolutionCardMainInfo>();
            }
        }
        public ObjectCollection<NetstatSolutionCardJournal> Journal
        {
            get
            {
                return (ObjectCollection<NetstatSolutionCardJournal>)base.GetValue(NetstatSolutionCard.JournalProperty);
            }
            set
            {
                base.SetValue(NetstatSolutionCard.JournalProperty, value);
            }
        }


        static NetstatSolutionCard()
        {
            NetstatSolutionCard.MainInfoProperty = ObjectProperty.Register("MainInfo", typeof(ObjectCollection<NetstatSolutionCardMainInfo>), typeof(NetstatSolutionCard));
            NetstatSolutionCard.JournalProperty = ObjectProperty.Register("Journal", typeof(ObjectCollection<NetstatSolutionCardJournal>), typeof(NetstatSolutionCard));
        }

        internal NetstatSolutionCard()
        {
        }
        internal NetstatSolutionCard(ObjectInitializationData data)
            : base(data)
        {
        }
    }
}
