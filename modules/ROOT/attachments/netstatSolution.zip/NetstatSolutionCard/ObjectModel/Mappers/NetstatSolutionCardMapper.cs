﻿using DocsVision.BackOffice.ObjectModel.Mapping;
using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetstatSolutionCard.ObjectModel.Mappers
{
    public class NetstatSolutionCardMapper : BaseCardMapper<NetstatSolutionCard>
    {
        private static ObjectMap map;
		static NetstatSolutionCardMapper()
		{
			NetstatSolutionCardMapper.InitializeObjectMap();
		}
		public NetstatSolutionCardMapper(ObjectContext context) : base(context)
		{
		}
        protected override NetstatSolutionCard CreateObject(ObjectInitializationData data)
		{
            return new NetstatSolutionCard(data);
		}

		protected override ObjectMap GetObjectMap()
		{
            return NetstatSolutionCardMapper.map;
		}
		private static void InitializeObjectMap()
		{
            NetstatSolutionCardMapper.map = new ObjectMap();
            NetstatSolutionCardMapper.map.ObjectTypeId = NetstatSolutionCardDefs.ID;
            NetstatSolutionCardMapper.map.Collection(NetstatSolutionCard.MainInfoProperty, NetstatSolutionCardDefs.MainInfo.ID);
            NetstatSolutionCardMapper.map.Collection(NetstatSolutionCard.JournalProperty, NetstatSolutionCardDefs.Journal.ID);
		}
    }
}
