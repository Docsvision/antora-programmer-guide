﻿using DocsVision.Platform.ObjectModel;
using DocsVision.Platform.ObjectModel.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetstatSolutionCard.ObjectModel.Mappers
{
    public class NetstatSolutionMapperFactory : ObjectMapperFactory
    {
        public NetstatSolutionMapperFactory(ObjectContext context)
            : base(context)
        {
            base.RegisterObjectMapper(typeof(NetstatSolutionCard), typeof(NetstatSolutionCardMapper));
            base.RegisterObjectMapper(typeof(NetstatSolutionCardMainInfo), typeof(NetstatSolutionCardMainInfoMapper));
            base.RegisterObjectMapper(typeof(NetstatSolutionCardJournal), typeof(NetstatSolutionCardJournalMapper));
        }
    }
}
