﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.Platform.ObjectModel;

namespace NetstatSolutionCard.ObjectModel
{
    public class NetstatSolutionCardMainInfo : BaseCardSectionRow
    {
        // В начале идет объявление всех доступных полей. Всегда типа ObjectProperty. 
        // Рекомендуется использовать название поля из схемы метаданных с добавлением суффикса Property
        public static readonly ObjectProperty NameProperty; // Название узла
        public static readonly ObjectProperty AddressProperty; // IP-адрес узла
        public static readonly ObjectProperty TypeProperty; // Тип узла
        public static readonly ObjectProperty IsCheckedProperty; //Требуется проверка
        public static readonly ObjectProperty LastResultProperty; //Результат последней проверки
        

        // Публичные свойства для обращения получения и записи значения соответствующего поля
        // Тип свойства соответствует типу поля в схеме метаданных
        // Для ссылочных полей тип соответствует типу сущности, на которую идет ссылка. В данном случае - это объектная объект сотрудник
        public string Name
        {
            get { return (string)base.GetValue(NetstatSolutionCardMainInfo.NameProperty); }
            set { base.SetValue(NetstatSolutionCardMainInfo.NameProperty, value); }
        }
        public string Address
        {
            get { return (string)base.GetValue(NetstatSolutionCardMainInfo.AddressProperty); }
            set { base.SetValue(NetstatSolutionCardMainInfo.AddressProperty, value); }
        }
        public int Type
        {
            get { return (int)base.GetValue(NetstatSolutionCardMainInfo.TypeProperty); }
            set { base.SetValue(NetstatSolutionCardMainInfo.TypeProperty, value); }
        }
        public bool IsChecked
        {
            get { return (bool)base.GetValue(NetstatSolutionCardMainInfo.IsCheckedProperty); }
            set { base.SetValue(NetstatSolutionCardMainInfo.IsCheckedProperty, value); }
        }
        public bool LastResult
        {
            get { return (bool)base.GetValue(NetstatSolutionCardMainInfo.LastResultProperty); }
            set { base.SetValue(NetstatSolutionCardMainInfo.LastResultProperty, value); }
        }

        // Обязательный статический конструктор, в котором должна быть выполнена регистрация всех объявленных ранее свойств
        static NetstatSolutionCardMainInfo()
        {
            // В метод Register передаем название поля (как в схеме метаданных), его тип (как определен выше) и тип самой секции (текущий класс)
            NetstatSolutionCardMainInfo.NameProperty = ObjectProperty.Register("Name", typeof(string), typeof(NetstatSolutionCardMainInfo));
            NetstatSolutionCardMainInfo.AddressProperty = ObjectProperty.Register("Address", typeof(string), typeof(NetstatSolutionCardMainInfo));
            NetstatSolutionCardMainInfo.TypeProperty = ObjectProperty.Register("Type", typeof(int), typeof(NetstatSolutionCardMainInfo));
            NetstatSolutionCardMainInfo.IsCheckedProperty = ObjectProperty.Register("IsChecked", typeof(bool), typeof(NetstatSolutionCardMainInfo));
            NetstatSolutionCardMainInfo.LastResultProperty = ObjectProperty.Register("LastResult", typeof(bool), typeof(NetstatSolutionCardMainInfo));
        }

        // Конструктор для новой карточки
        internal NetstatSolutionCardMainInfo()
        {
        }

        // Конструктор для существующей карточки с загрузкой данных	
        internal NetstatSolutionCardMainInfo(ObjectInitializationData data)
            : base(data)
        {
        }
    }
}
