﻿namespace GoogleDriveStorageProvider.Forms
{
    partial class GoogleDriveProviderPropertyControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            CredentialFile = new TextBox();
            LogFile = new TextBox();
            label3 = new Label();
            AdministrativeEmail = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AccessibleRole = AccessibleRole.ScrollBar;
            label1.AutoSize = true;
            label1.Location = new Point(8, 10);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(165, 15);
            label1.TabIndex = 2;
            label1.Text = "Путь к файлу credentials.json";
            // 
            // CredentialFile
            // 
            CredentialFile.Location = new Point(211, 7);
            CredentialFile.Margin = new Padding(4, 3, 4, 3);
            CredentialFile.Name = "CredentialFile";
            CredentialFile.Size = new Size(167, 23);
            CredentialFile.TabIndex = 3;
            CredentialFile.TextChanged += CredentialFile_TextChanged;
            // 
            // LogFile
            // 
            LogFile.Location = new Point(211, 56);
            LogFile.Margin = new Padding(4, 3, 4, 3);
            LogFile.Name = "LogFile";
            LogFile.Size = new Size(167, 23);
            LogFile.TabIndex = 7;
            LogFile.TextChanged += LogFile_TextChanged;
            // 
            // label3
            // 
            label3.AccessibleRole = AccessibleRole.ScrollBar;
            label3.AutoSize = true;
            label3.Location = new Point(8, 59);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(95, 15);
            label3.TabIndex = 6;
            label3.Text = "Журнал работы";
            // 
            // AdministrativeEmail
            // 
            AdministrativeEmail.Location = new Point(211, 31);
            AdministrativeEmail.Margin = new Padding(4, 3, 4, 3);
            AdministrativeEmail.Name = "AdministrativeEmail";
            AdministrativeEmail.Size = new Size(167, 23);
            AdministrativeEmail.TabIndex = 8;
            AdministrativeEmail.TextChanged += AdministrativeEmail_TextChanged;
            // 
            // label2
            // 
            label2.AccessibleRole = AccessibleRole.ScrollBar;
            label2.AutoSize = true;
            label2.Location = new Point(8, 34);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(148, 15);
            label2.TabIndex = 9;
            label2.Text = "Административный email";
            // 
            // GoogleDriveProviderPropertyControl
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Controls.Add(label2);
            Controls.Add(AdministrativeEmail);
            Controls.Add(LogFile);
            Controls.Add(label3);
            Controls.Add(CredentialFile);
            Controls.Add(label1);
            Margin = new Padding(4, 3, 4, 3);
            Name = "GoogleDriveProviderPropertyControl";
            Padding = new Padding(4, 3, 4, 3);
            Size = new Size(386, 85);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox CredentialFile;
        private TextBox LogFile;
        private Label label3;
        private TextBox AdministrativeEmail;
        private Label label2;
    }
}
