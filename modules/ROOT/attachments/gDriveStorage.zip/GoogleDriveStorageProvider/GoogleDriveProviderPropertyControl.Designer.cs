﻿namespace GoogleDriveStorageProvider
{
    partial class GoogleDriveProviderPropertyControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CredentialFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TokenFolder = new System.Windows.Forms.TextBox();
            this.LogFile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Путь к файлу credentials.json";
            // 
            // CredentialFile
            // 
            this.CredentialFile.Location = new System.Drawing.Point(181, 6);
            this.CredentialFile.Name = "CredentialFile";
            this.CredentialFile.Size = new System.Drawing.Size(144, 20);
            this.CredentialFile.TabIndex = 3;
            this.CredentialFile.TextChanged += new System.EventHandler(this.CredentialFile_TextChanged);
            // 
            // label2
            // 
            this.label2.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Каталог для сохранения токена";
            // 
            // TokenFolder
            // 
            this.TokenFolder.Location = new System.Drawing.Point(181, 31);
            this.TokenFolder.Name = "TokenFolder";
            this.TokenFolder.Size = new System.Drawing.Size(144, 20);
            this.TokenFolder.TabIndex = 5;
            this.TokenFolder.TextChanged += new System.EventHandler(this.TokenFolder_TextChanged);
            // 
            // LogFile
            // 
            this.LogFile.Location = new System.Drawing.Point(181, 57);
            this.LogFile.Name = "LogFile";
            this.LogFile.Size = new System.Drawing.Size(144, 20);
            this.LogFile.TabIndex = 7;
            this.LogFile.TextChanged += new System.EventHandler(this.LogFile_TextChanged);
            // 
            // label3
            // 
            this.label3.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Журнал работы";
            // 
            // GoogleDriveProviderPropertyControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.LogFile);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TokenFolder);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CredentialFile);
            this.Controls.Add(this.label1);
            this.Name = "GoogleDriveProviderPropertyControl";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.Size = new System.Drawing.Size(331, 83);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CredentialFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TokenFolder;
        private System.Windows.Forms.TextBox LogFile;
        private System.Windows.Forms.Label label3;
    }
}
