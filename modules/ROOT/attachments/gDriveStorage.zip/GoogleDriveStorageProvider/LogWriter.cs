﻿using System;
using System.Globalization;
using System.IO;

namespace GoogleDriveStorageProvider
{
    /// <summary>
    /// Ведение журнала работы
    /// </summary>
    public class LogWriter
    {
        bool logOn = false;
        string logFile;
        private readonly object writeLock = new object();
        
        public LogWriter()
        {
        }

        public LogWriter(string logFile)
        {
            if (logFile == null)
                return;
               
            this.logFile = logFile;
            logOn = true;
        }

        public void Write(string message)
        {
            if (logOn == false)
                return;

            lock (writeLock)
            {
                File.AppendAllText(logFile,
                    DateTime.Now.ToString("G", CultureInfo.CreateSpecificCulture("ru-RU")) + " " + message + Environment.NewLine);
            }
        }
    }
}
