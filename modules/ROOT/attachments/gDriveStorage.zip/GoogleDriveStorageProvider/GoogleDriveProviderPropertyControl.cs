﻿using DocsVision.Platform.WinForms.Controls;
using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace GoogleDriveStorageProvider
{
    public partial class GoogleDriveProviderPropertyControl : UserControl, IExtensionPropertiesControl
    {

        public GoogleDriveProviderPropertyControl()
        {
            InitializeComponent();
        }

        public string Settings
        {
            get;
            private set;
        }

        public event EventHandler OnPropertiesChanged;

        // Вызывается при загрузке компонента 
        public void Initialize(string settings)
        {
            Settings = settings;

            var providerSettings = new ProviderSettings(settings);

            CredentialFile.Text = providerSettings.CredentialsFilePath;
            TokenFolder.Text = providerSettings.TokenFolder;
            LogFile.Text = providerSettings.LogFile;
        }

        // Вызывается при сохранении настроек
        public bool Save()
        {
            string credentialsFile = CredentialFile.Text.Trim();
            string tokenFolder = TokenFolder.Text.Trim();
            string logFile = LogFile.Text.Trim();

            StringBuilder checkResult = new StringBuilder();

            if (string.IsNullOrEmpty(credentialsFile)) checkResult.Append("Не указан путь к файлу credentials.json");
            else if (!File.Exists(credentialsFile)) checkResult.Append("Файл " + credentialsFile + " не существует.");

            if (string.IsNullOrEmpty(tokenFolder)) checkResult.Append("Не указан каталог для сохранения токена");
            else if (!Directory.Exists(tokenFolder)) checkResult.Append("Каталог " + tokenFolder + " не существует.");

            if (!Directory.Exists(Path.GetDirectoryName(logFile))) checkResult.Append("Указанный каталог для журнала не существует");
            
            if (checkResult.Length > 0)
            {
                MessageBox.Show(checkResult.ToString());
                return false;
            }

            var settings = new ProviderSettings()
            {
                CredentialsFilePath = credentialsFile,
                TokenFolder = tokenFolder,
                LogFile = logFile
            };

            Settings = settings.ToString();

            return true;
        }

        private void CredentialFile_TextChanged(object sender, EventArgs e)
        {
            if (OnPropertiesChanged != null)
                OnPropertiesChanged(sender, e);

        }

        private void TokenFolder_TextChanged(object sender, EventArgs e)
        {
            if (OnPropertiesChanged != null)
                OnPropertiesChanged(sender, e);
        }

        private void LogFile_TextChanged(object sender, EventArgs e)
        {
            if (OnPropertiesChanged != null)
                OnPropertiesChanged(sender, e);
        }
    }
}
