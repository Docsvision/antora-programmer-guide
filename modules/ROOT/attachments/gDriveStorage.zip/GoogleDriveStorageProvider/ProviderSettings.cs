﻿using System.Text.Json;

namespace GoogleDriveStorageProvider
{
    public class ProviderSettings
    {
        public string CredentialsFilePath { get; set; }
        public string AdministrativeEmail { get; set; }
        public string LogFile { get; set; }

        public ProviderSettings()
        {
        }


        public ProviderSettings(string setting)
        {
            if (string.IsNullOrEmpty(setting))
                return;

            ProviderSettings settings = JsonSerializer.Deserialize<ProviderSettings>(setting); ;

            CredentialsFilePath = settings.CredentialsFilePath;
            AdministrativeEmail = settings.AdministrativeEmail;
            LogFile = settings.LogFile;
        }


        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
