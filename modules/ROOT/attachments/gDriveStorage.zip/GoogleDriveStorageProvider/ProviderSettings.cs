﻿namespace GoogleDriveStorageProvider
{
    public class ProviderSettings
    {
        public string CredentialsFilePath { get; set; }
        public string TokenFolder { get; set; }
        public string LogFile { get; set; }


        public ProviderSettings()
        {
        }

        public ProviderSettings(string setting)
        {
            if (string.IsNullOrEmpty(setting))
                return;

            string[] settings = setting.Split(';');

            if (settings.Length == 3)
            {
                CredentialsFilePath = settings[0];
                TokenFolder = settings[1];
                LogFile = settings[2];
            }
        }

        public override string ToString()
        {
            return CredentialsFilePath + ";" + TokenFolder + ";" + LogFile;
        }
    }
}
