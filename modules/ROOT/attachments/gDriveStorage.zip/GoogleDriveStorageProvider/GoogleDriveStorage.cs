﻿using DocsVision.Platform.StorageServer;
using DocsVision.Platform.StorageServer.Files;
using System;
using System.ComponentModel;
using System.IO;
using System.Collections.Generic;

namespace GoogleDriveStorageProvider
{

    /// <summary>
    /// Реализация класса провайдера к внешнему хранилищу Google Drive
    /// </summary>

    [LocalizedDisplayName("GoogleDriveStorage")]
    [Editor("GoogleDriveStorageProvider.GoogleDriveProviderPropertyControl, GoogleDriveStorageProvider, Version=1.0.0.0, Culture=neutral, PublicKeyToken=3738734bfe4d30d7, processorArchitecture=MSIL"
        , "DocsVision.Platform.WinForms.Controls.IExtensionPropertiesControl, DocsVision.Platform.WinForms"
    )]
    public class GoogleDriveStorage : IBinaryStorage, IExtensionInitialize, IStreamedBinaryStorage, IEnumerableBinaryStorage
    {

        // Уникальный идентификатор хранилища
        Guid storageId = Guid.Parse("783D93D5-D93F-456A-8CE0-11DA2E29DC3F");

        // Типы разделов, поддерживаемые хранилищем 
        private StoragePartitionType _supportedPartitions;


        private static GoogleDriveProxy googleDriveProxy;

        public GoogleDriveStorage()
        {
            // При инициализации хранилища, выполняется загрузка разделов, поддерживаемых по умолчанию данным типом хранилища
            _supportedPartitions = GetDefaultPartitions();
        }

        /* 
         * Реализация интерфейса IBinaryStorage
         */

        // Признак встроенного (в Docsvision) хранилища
        // Всегда должен возвращать FALSE !
        public bool IsIntegratedStorage
        {
            get
            {
                return false;
            }
        }

        // Уникальный идентификатор хранилища
        public Guid StorageId
        {
            get
            {
                return storageId;
            }

            set
            {
                storageId = value;
            }
        }

        // Типы разделов, поддерживаемые хранилищем 
        public StoragePartitionType SupportedPartions
        {
            get
            {
                return _supportedPartitions;
            }
            set
            {
                _supportedPartitions = GetDefaultPartitions() & value;
            }
        }

        // Проверяет возможность перемещения файла в другой раздел хранилища без изменения данных
        public bool CanSafelyMove(string id, StoragePartitionType toPartition)
        {
            try
            {
                var partId = googleDriveProxy.GetFilePartition(id);
                if (partId == (int)toPartition)
                    return false;
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }

            return true;
        }

        // Создает файла в хранилище
        public string Create(IFileInfo fileInfo, StoragePartitionType onPartition = StoragePartitionType.Primary)
        {
            try
            {
                return googleDriveProxy.GenerateId(fileInfo.Name, fileInfo.FileId.ToString(), (int)onPartition);
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Создает файла в хранилище с загрузкой данных существующего файла
        public string CreateFrom(IFileInfo fileInfo, string sourceId, StoragePartitionType onPartition = StoragePartitionType.Primary)
        {
            try
            {
                return googleDriveProxy.Copy(sourceId, (int)onPartition);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл sourceId не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Удаляет файл из хранилища
        public void Delete(string id)
        {
            try
            {
                googleDriveProxy.Delete(id);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Считывает данные файла id в поток stream
        public void Read(string id, Stream stream)
        {
            try
            {
                googleDriveProxy.Read(id, stream);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Считывает данные файла id в поток destStream с позиции position, количество считываемых данных maxBytes
        public long Read(string id, Stream destStream, long position, int maxBytes)
        {
            try
            {
                return googleDriveProxy.Read(id, destStream, position, position + maxBytes);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Перемещает файл id в раздел toPartition и возвращает идентификатор файла после перемещения
        public string SafeMove(string id, StoragePartitionType toPartition)
        {
            try
            {
                googleDriveProxy.Move(id, (int)toPartition);
                return id;
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Записывает в файл id данные из потока sourceStream
        public long Write(string id, Stream sourceStream)
        {
            try
            {
                googleDriveProxy.Write(id, sourceStream);
                return sourceStream.Length;
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException(); // Если файл не существует вызывает исключение BinaryNotFoundException
            }
            catch
            {
                throw new BinaryStorageException();
            }

        }

        // Записывает в файл id данные из потока sourceStream начиная с позиции position
        public long Write(string id, Stream sourceStream, long position)
        {
            throw new NotSupportedException(); // Сообщаем, что данная функция не поддерживается
        }


        /*
         * Реализация интерфейса IExtensionInitialize
         */

        // Инициализирует провайдер к хранилищу
        public void Initialize(IServiceProvider serviceProvider, string settings)
        {

            // Обратите внимание: метод Initialize может вызываться несколько раз после запуска сервера,
            //  поэтому используется статический объект для работы с Google Drive
            if (googleDriveProxy == null)
            {
                var providerSettings = new ProviderSettings(settings);

                googleDriveProxy = new GoogleDriveProxy(providerSettings.CredentialsFilePath, providerSettings.TokenFolder, providerSettings.LogFile);

            }
        }

        
        /* 
         * Реализация интерфейса IStreamedBinaryStorage
        */

        // Возвращает поток для чтения данных файла
        public Stream OpenReadStream(string id)
        {
            try
            {
                return googleDriveProxy.ReadStream(id);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException();
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }


        // Возвращает поток для записи данных файла
        public Stream OpenWriteStream(string id)
        {
            try
            {
                return googleDriveProxy.WriteStream(id);
            }
            catch (FileNotFoundException)
            {
                throw new BinaryNotFoundException();
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }


        /* 
         * Реализация интерфейса IEnumerableBinaryStorage
         */
         
        // Возвращает идентификаторы файлов в хранилище
        public IEnumerable<string> GetEnumerable(StoragePartitionType partitionType)
        {
            try
            {
                return googleDriveProxy.GetFilesIdsInPartition((int)partitionType);
            }
            catch
            {
                throw new BinaryStorageException();
            }
        }

        // Список разделов, поддерживаемых по умолчанию
        protected StoragePartitionType GetDefaultPartitions()
        {
            return StoragePartitionType.Primary | StoragePartitionType.Archive;
        }
    }
}
