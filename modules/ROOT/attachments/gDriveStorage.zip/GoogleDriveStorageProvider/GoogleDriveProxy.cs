﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace GoogleDriveStorageProvider
{
    public class GoogleDriveProxy
    {
        static readonly string[] Scopes = { DriveService.Scope.Drive };

        /// <summary>
        /// Типы хранилищ; повторяет перечисление Docsvision
        /// </summary>
        [Flags]
        public enum PartitionType
        {
            Default = 0,
            Primary = 1,
            Archive = 2,
            Temp = 4,
        }

        /// <summary>
        /// Содержит информацию о разделе хранилища
        /// </summary>
        public struct PartitionInfo
        {
            public string FolderName { get; set; }
            public string FolderId { get; set; }
        }

        // Информация о разделах хранилища
        private readonly Dictionary<PartitionType, PartitionInfo> partitions = new Dictionary<PartitionType, PartitionInfo>()
        {
            { PartitionType.Primary, new PartitionInfo() {
                FolderName = "DV_PrimaryPart",
                FolderId = null
            }},
            { PartitionType.Archive, new PartitionInfo() {
                FolderName = "DV_ArchivePart",
                FolderId = null
            } }
        };

        private readonly DriveService gdService;
        private readonly LogWriter logWriter;
        private readonly Permission permissionForAdministrator;


        /// <summary>
        /// Конструктор класса-посредника к Google Drive
        /// В методе выполняется загрузка с диска или генерация нового токена для работы с Google Drive
        /// </summary>
        /// <param name="credentialsFile">Файл с клиентскими секретами</param>
        /// <param name="administratorEmail">Почта администратора (будкт предоставлен доступ на просмотр файлов)</param>
        /// <param name="logFile">Путь к файлу журнала работы</param>
        public GoogleDriveProxy(string credentialsFile, string administratorEmail = null, string logFile = null)
        {
            logWriter = new LogWriter(logFile);
            permissionForAdministrator = CreatePermissionForAdministrator(administratorEmail);

            GoogleCredential credential;

            // Если файл с токеном существует, будет загружен он, иначе создан новый
            // Т.к. для создания токена вызывается окно браузера, необходимо предварительно создать токен, вызывав GoogleDriveProxy из программы AskToken
            using (var stream =
                new FileStream(credentialsFile, FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                .CreateScoped(Scopes);
            }

            // Создания сервиса для работы с Google Drive API
            gdService = new DriveService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "Docsvision to Google Drive provider",
            });

            CollectPartitionsId();
        }

      
        /// <summary>
        /// Получение списка идентификаторов папок, представляющих разделы хранилища
        /// </summary>
        void CollectPartitionsId()
        {
            string pageToken = null;
            do
            {
                var request = gdService.Files.List();
                request.Q = "mimeType='application/vnd.google-apps.folder' and 'root' in parents and trashed=false";
                request.Spaces = "drive";
                request.Fields = "nextPageToken, files(id, name)";
                request.PageToken = pageToken;

                var folder = request.Execute().Files;

                foreach (var part in partitions.ToList())
                {
                    var partInfo = part.Value;
                    var partFolder = folder.Where(t => t.Name == partInfo.FolderName);


                    if (partFolder.Count() == 0)
                    {
                        string id = CreateFolder(partInfo.FolderName);
                        partInfo.FolderId = id;
                        partitions[part.Key] = partInfo;
                    }
                    else if (partFolder.Count() == 1)
                    {
                        partInfo.FolderId = partFolder.Single().Id;
                        partitions[part.Key] = partInfo;
                    }
                }

            } while (pageToken != null);

            logWriter.Write("Получены идентификаторы папок-разделов хранилища");
        }


        /// <summary>
        /// Получение идентификатора для создаваемого файла
        /// </summary>
        /// <param name="fileName">Название файла</param>
        /// <param name="sourceId">Идентификатор файла, переданный из Docsvision</param>
        /// <param name="partition">Раздел, в который планируется добавить файл</param>
        /// <returns></returns>
        public string GenerateId(string fileName, string sourceId, int partition)
        {
            var fileMetadata = new Google.Apis.Drive.v3.Data.File()
            {
                Name = fileName,
                OriginalFilename = sourceId,
                Parents = new string[] { partitions[(PartitionType)partition].FolderId }
            };

            FilesResource.CreateRequest request = gdService.Files.Create(fileMetadata);

            string fileId;
            try
            {
                fileId = request.Execute().Id;
            }
            catch
            {
                throw new FileNotFoundException();
            }

            logWriter.Write("Сформирован идентификатор для файла: " + fileName + ". Идентификатор: " + fileId);
            
            ShareFile(fileId);
            
            return fileId;
        }

        /// <summary>
        /// Записывает данные в файл из потока
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <param name="sourceStream">Поток данных</param>
        /// <returns>Количество записанных данных</returns>
        public long Write(string fileId, Stream sourceStream)
        {
            string fileName = TestFileExist(fileId);

            // Используется упрощенный способ получение MimeType по расширению файла
            // Также можно использовать, к примеру, метод System.Web.MimeMapping.GetMimeMapping или иные способы
            string mimeType = GetMimeType(fileName);

            var request = gdService.Files.Update(null, fileId, sourceStream, mimeType);
            var result = request.Upload();
            var totalBytesSent = result.BytesSent;
            logWriter.Write("Запись данных в файл: " + fileId);

            return totalBytesSent;
        }

        private void ShareFile(string fileId)
        {
            if (permissionForAdministrator == null)
                return;

            PermissionsResource.CreateRequest createRequest = gdService.Permissions.Create(permissionForAdministrator, fileId);
            createRequest.UseDomainAdminAccess = false;
            createRequest.Execute();
        }

        /// <summary>
        /// Пердоставляет поток для записи в файл
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <returns>Поток записи</returns>
        public Stream WriteStream(string fileId)
        {
            TestFileExist(fileId);

            var request = gdService.Files.Update(null, fileId);

            logWriter.Write("Запись данных в файл: " + fileId);
            return request.ExecuteAsStream();
        }

        /// <summary>
        /// Считывает данные в поток
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <param name="destinationStream">Поток, в который считываются данные файла</param>
        public void Read(string fileId, Stream destinationStream)
        {
            TestFileExist(fileId);

            var request = gdService.Files.Get(fileId);

            using (var memoryStream = new MemoryStream())
            {
                request.DownloadWithStatus(memoryStream);
                memoryStream.WriteTo(destinationStream);
            }

            logWriter.Write("Считаны данные файла: " + fileId);
        }

        /// <summary>
        /// Считывает данные в поток
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <param name="destinationStream">Поток, в который считываются данные файла</param>
        /// <param name="from">Начальная позиция считывания</param>
        /// <param name="to">Конечная позиция считывания</param>
        /// <returns>Количество считанных данных</returns>
        public long Read(string fileId, Stream destinationStream, long from, long to)
        {
            TestFileExist(fileId);

            var request = gdService.Files.Get(fileId);
            var result = request.DownloadRange(destinationStream, new System.Net.Http.Headers.RangeHeaderValue(from, to));

            logWriter.Write("Считаны данные файла: " + fileId);
            return result.BytesDownloaded;
        }

        /// <summary>
        /// Считывает данные файла в поток
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <returns>Поток чтения</returns>
        public Stream ReadStream(string fileId)
        {
            TestFileExist(fileId);

            var stream = new MemoryStream();
            var request = gdService.Files.Get(fileId);
            request.Download(stream);

            logWriter.Write("Считаны данные файла: " + fileId);
            return stream;
        }

        /// <summary>
        /// Удаляет файл из хранилища
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        public void Delete(string fileId)
        {
            TestFileExist(fileId);

            var deleteRequest = gdService.Files.Delete(fileId);
            deleteRequest.Execute();

            logWriter.Write("Удален файл: " + fileId);
        }

        /// <summary>
        /// Перемещает файл
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <param name="toPartition">Идентификатор раздела, в который перемещается файл</param>
        public void Move(string fileId, int toPartition)
        {
            TestFileExist(fileId);

            var partitionType = (PartitionType)toPartition;

            var getRequest = gdService.Files.Get(fileId);
            getRequest.Fields = "parents";
            var file = getRequest.Execute();
            var previousParents = String.Join(",", file.Parents);

            var updateRequest = gdService.Files.Update(new Google.Apis.Drive.v3.Data.File(), fileId);
            updateRequest.Fields = "id, parents";
            updateRequest.AddParents = partitions[partitionType].FolderId;
            updateRequest.RemoveParents = previousParents;
            file = updateRequest.Execute();

            logWriter.Write("Файл " + file.OriginalFilename + " перемещен в раздел " + partitions[partitionType].FolderName);
        }

        /// <summary>
        /// Копирует файл между хранилищами
        /// </summary>
        /// <param name="fileId">Идентификатор копируемого файла</param>
        /// <param name="toPartition">Раздел хранилища, в который копируется файл</param>
        /// <returns>Идентификатор созданного файла</returns>
        public string Copy(string fileId, int toPartition)
        {
            TestFileExist(fileId);

            var getRequest = gdService.Files.Get(fileId);
            getRequest.Fields = "parents";
            var file = getRequest.Execute();
            file.Parents = new string[] { partitions[(PartitionType)toPartition].FolderId };

            var copyRequest = gdService.Files.Copy(file, fileId);
            var newFile = copyRequest.Execute();

            logWriter.Write("Скопирован файл: " + fileId);
            return newFile.Id;
        }

        /// <summary>
        /// Получает идентификаторы файлов в разделе хранилища
        /// </summary>
        /// <param name="toPartition">Раздел хранилища</param>
        /// <returns>Список идентификаторов файлов</returns>
        public IEnumerable<string> GetFilesIdsInPartition(int toPartition)
        {
            string pageToken = null;
            PartitionType partitionType = (PartitionType)toPartition;

            List<string> ids = new List<string>();

            do
            {
                var request = gdService.Files.List();

                var partitionFolderId = partitions[partitionType].FolderId;

                request.Q = "'" + partitionFolderId + "' in parents and trashed=false";
                request.Spaces = "drive";
                request.Fields = "nextPageToken, files(id)";
                request.PageToken = pageToken;

                var files = request.Execute().Files;

                foreach (var file in files)
                {
                    ids.Add(file.Id);
                }

            } while (pageToken != null);


            logWriter.Write("Получены идентификаторы файлов в разделе " + partitionType);
            return ids;
        }

        /// <summary>
        /// Возвращает раздел хранилища, в котором размещен файла
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <returns>Раздел хранилища</returns>
        public int GetFilePartition(string fileId)
        {
            TestFileExist(fileId);

            var request = gdService.Files.Get(fileId);
            request.Fields = "parents";

            var files = request.Execute();

            if (files.Parents == null)
                throw new Exception("У файла " + fileId + " отсутствуют родительские папки");

            var parentId = files.Parents.First();

            if (partitions.Values.Any(t => t.FolderId == parentId))
                return (int)partitions.Where(t => t.Value.FolderId == parentId).First().Key;
            else
                throw new Exception("Файл " + fileId + " размещен в нестандартной папке " + parentId);
        }

        /// <summary>
        /// Проверят существование файла в Google Drive
        /// Если файл не существует вызывается исключение FileNotFoundException
        /// </summary>
        /// <param name="fileId">Идентификатор файла</param>
        /// <returns>Название файла</returns>
        private string TestFileExist(string fileId)
        {
            var request = gdService.Files.Get(fileId);
            request.Fields = "name";

            try
            {
                return request.Execute().Name;
            }
            catch
            {
                throw new FileNotFoundException();
            }
        }

        /// <summary>
        /// Создает папку в Google Drive
        /// </summary>
        /// <param name="folderName">Название папки</param>
        /// <returns>Идентификатор папки</returns>
        private string CreateFolder(string folderName)
        {
            var fileMetadata = new Google.Apis.Drive.v3.Data.File()
            {
                Name = folderName,
                MimeType = "application/vnd.google-apps.folder"
            };

            var request = gdService.Files.Create(fileMetadata).Execute();

            logWriter.Write("Создана папка: " + folderName);
            return request.Id;
        }


        /// <summary>
        /// Возвращает mimetype для файла
        /// </summary>
        /// <param name="fileName">Файл</param>
        /// <returns>MimeType</returns>
        string GetMimeType(string fileName)
        {
            string extension = Path.GetExtension(fileName).ToLower();

            // Основные файлы, загружаемые в Docsvision
            switch (extension)
            {
                case ".pdf":
                    return "application/pdf";

                case ".doc":
                    return "application/msword";

                case ".docx":
                    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

                default:
                    return "text/plain";
            }
        }

        private static Permission CreatePermissionForAdministrator(string administratorEmail)
        {
            if (string.IsNullOrEmpty(administratorEmail))
                return null;

            return new Permission
            {
                EmailAddress = administratorEmail,
                Role = "reader",
                Type = "user"
            };
        }

    }
}