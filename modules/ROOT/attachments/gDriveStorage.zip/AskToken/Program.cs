﻿
using GoogleDriveStorageProvider;

namespace AskToken
{

    /// <summary>
    /// Данное приложение инициализирует класс GoogleDriveProxy с целью создать токен для работы с Google Drive используя конфигурацию клиента из файла credentials.json
    /// Для получения credentials.json перейдите на страницу https://developers.google.com/drive/api/v3/quickstart/dotnet и следуйте инструкции из шага 1.
    /// Полученный
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            GoogleDriveProxy proxy = new GoogleDriveProxy("credentials.json", "token.json");
        }
    }
}
