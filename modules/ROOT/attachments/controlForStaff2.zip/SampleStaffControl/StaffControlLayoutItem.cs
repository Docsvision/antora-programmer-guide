﻿using DevExpress.Utils.Serializing;
using DocsVision.BackOffice.CardLib.CardDefs;
using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.WinForms.Design.LayoutItems;
using DocsVision.Platform.Data.Metadata.CardModel;
using System;
using System.Windows.Forms;

namespace SampleStaffControl
{
    // Контейнер для элемента управления 
    public class StaffControlLayoutItem : FixedLayoutControlItem<StaffPropertyControl>, IReferencePropertyItem
    {
        private Guid restrictionUnitId;
        private StaffEmployeeStatus? selectedEmployeeStatus;
        private bool hideNotActive = true;


        // Идентификатор подразделения, из которого разрешено выбирать сотрудников
        [XtraSerializableProperty]
        public Guid RestrictionUnitId
        {
            get
            {
                if (base.PropertyControl != null)
                    return base.PropertyControl.RestrictionUnitId;

                return restrictionUnitId;
            }
            set
            {
                if (this.PropertyControl != null)
                    this.PropertyControl.RestrictionUnitId = value;
                restrictionUnitId = value;
            }
        }

        // Состояние сотрудников, из списка которых можно выбирать
        [XtraSerializableProperty]
        public StaffEmployeeStatus? SelectedEmployeeStatus
        {
            get
            {
                if (base.PropertyControl != null)
                    return base.PropertyControl.SelectedEmployeeStatus;

                return selectedEmployeeStatus;
            }
            set
            {
                if (this.PropertyControl != null)
                    this.PropertyControl.SelectedEmployeeStatus = value;
                selectedEmployeeStatus = value;
            }
        }

        // Скрывать сотрудников с состоянием, отличным от Активен
        [XtraSerializableProperty]
        public bool HideNotActive
        {
            get
            {
                if (base.PropertyControl != null)
                    return base.PropertyControl.HideNotActive;

                return hideNotActive;
            }
            set
            {
                if (this.PropertyControl != null)
                    this.PropertyControl.HideNotActive = value;
                hideNotActive = value;
            }
        }


        // Название элемента управления, отображаемое в конструкторе разметок
        public override string ItemTypeName
        {
            get
            {
                return "Сотрудник с фотографией";
            }
        }

        // Тип данных в элементе управления. Необходим для конвертации значений по умолчанию.
        public override LayoutsPropertyType PropertyType
        {
            get { return LayoutsPropertyType.EmployeeReference; }
        }

        // Тип данных, поддерживаемый элементом управления. Необходим для ограничения списка полей, доступных для выбора.
        public override FieldType[] GetSupportedFieldTypes()
        {
            return new FieldType[] { FieldType.RefId };
        }

        // Переопределяем установку сущности элемента управления для проброса в него значений его параметров
        public override Control Control
        {
            get
            {
                return base.Control;
            }
            set
            {
                base.Control = value;
                if (value != null)
                {
                    // Передача значений свойств в элемент управления
                    this.PropertyControl.RestrictionUnitId = restrictionUnitId;
                    this.PropertyControl.SelectedEmployeeStatus = selectedEmployeeStatus;
                    this.PropertyControl.HideNotActive = hideNotActive;
                }
            }
        }

        #region Реализация интерфейса IReferencePropertyItem для элементов управления со ссылочными данными

        // Идентификатор типа карточки
        public Guid CardTypeId
        {
            get { return RefStaff.ID; }
        }


        // Идентификатор секции карточки
        public Guid SectionTypeId
        {
            get { return RefStaff.Employees.ID; }
        }

        public bool AllowUnresolved
        {
            get { return false; }
        }

        // Получаем значение ссылочного поля 
        public object GetLinkedFieldValue(string fieldName)
        {
            return this.PropertyControl.GetValue(fieldName);
        }

        #endregion
    }
}
