﻿using DocsVision.BackOffice.WinForms.Design;

namespace SampleStaffControl
{
    /// <summary>
    /// Класс, предоставляющий конструктору разметки сведения о реализованных в сборке элементах управления 
    /// </summary>
    public sealed class ExtensionPackage : ControlExtensionInfoPackage
    {
        // Возвращает информацию о элементах управления
        public override ControlExtensionInfo[] GetControlExtensions()
        {
            return new ControlExtensionInfo[]
			{
                // Аргументы конструктора:
                // Тип контейнера элемента управления
                // Тип обертки, в которой описаны свойства элемента управления для конструктора разметки
                // Тип формы (Windows Forms), которой будет подменена основная форма со свойствами элемента управления
				new ControlExtensionInfo(typeof(StaffControlLayoutItem), typeof(StaffControlWrapper),typeof(StaffPropertySettingsForm))
			};
        }
    }
}
