﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.Platform.ObjectModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SampleStaffControl
{
    /// <summary>
    /// Преобразует идентификатор подразделения в название
    /// </summary>
    class UnitConverter : TypeConverter
    {
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            return destinationType == typeof(string) ? true : base.CanConvertTo(context, destinationType);
        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            StaffControlWrapper wrapper = context.Instance as StaffControlWrapper;
            if (wrapper != null)
            {
                if (wrapper.RestrictionUnitId == Guid.Empty)
                    return string.Empty;

                try
                {
                    StaffUnit unit = StaticObjectContext.Current.GetObject<StaffUnit>(wrapper.RestrictionUnitId);
                    return string.Format(unit.Name);
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.ToString());
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}


