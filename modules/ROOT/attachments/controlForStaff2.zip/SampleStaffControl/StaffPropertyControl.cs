﻿using DevExpress.XtraEditors;
using DocsVision.BackOffice.CardLib.CardDefs;
using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.ObjectModel.Services;
using DocsVision.BackOffice.WinForms;
using DocsVision.BackOffice.WinForms.Design.PropertyControls;
using DocsVision.Platform.ObjectManager;
using DocsVision.Platform.ObjectModel;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleStaffControl
{
    public partial class StaffPropertyControl : XtraUserControl, IPropertyControl
    {
        IStaffService StaffService
        {
            get
            {
                return ObjectContext.GetService<IStaffService>();
            }
        }

        // Свойство, которое возвращает флаг работы в режиме редактирования разметки
        bool IsDesignMode
        {
            get
            {
                return ObjectContext.GetService<BaseCardControl>().CardData.Type.Id == DocsVision.BackOffice.CardLib.CardDefs.RefLayouts.ID;
            }
        }

        // Значение и контекст объектов
        object controlValue;
        ObjectContext objectContext;

        // Идентификатор подразделения, сотрудники которого отображаются в списке
        public Guid RestrictionUnitId { get; set; }

        // Состояние сотрудников, отображаемых в списке
        public StaffEmployeeStatus? SelectedEmployeeStatus { get; set; }

        public bool HideNotActive { get; set; }

        public StaffPropertyControl()
        {
            InitializeComponent();
            this.staffControl1.SelectionChanged += staffControl1_SelectionChanged;
        }

        #region Реализация IPropertyControl

        // Если false - то включен режим чтения
        public bool AllowEdit { get; set; }

        public object ControlValue
        {
            get
            {
                return controlValue;
            }
            set
            {
                // Если элемент управления в конструкторе разметок, то данные загружать не требуется
                if (controlValue != value)
                    SelectItem(value);
            }
        }

        public ObjectContext ObjectContext
        {
            get
            {
                return objectContext;
            }

            set
            {
                objectContext = value;
                if (!IsDesignMode)
                {
                    LoadData();
                }
            }
        }

        public bool ShowBorder { get; set; }

        public bool Signed { get; set; }

        public string ToolTip { get; set; }

        //Реакция на Commit - сохранение данных
        public void Commit()
        {
        }

        // Значение по умолчанию
        public object GetDefaultControlValue()
        {
            return ObjectContext.GetObjectRef(StaffService.GetCurrentEmployee()).Id;
        }

        // Копирование значения элемента управления
        public object GetValueCopy()
        {
            return this.ControlValue;
        }

        public event EventHandler ControlValueChanged;

        #endregion

        // Обработка установки значения ControlValue, при этом нужный сотрудник выбирается в списке сострудников
        // Данный метод будет вызван только при работе с карточкой
        private void SelectItem(object value)
        {
            Guid employeeId = Guid.Empty;
            bool parseOk = false;
            try
            {
                parseOk = Guid.TryParse(value.ToString(), out employeeId);
            }
            catch { }

            this.staffControl1.SelectItem(parseOk ? (Guid?)employeeId : null);
        }

        /// <summary>
        /// Загружает данные из справочника сотрудников Docsvision
        /// </summary>
        private void LoadData()
        {
            StaffUnit restrictionUnit = null;
            if (RestrictionUnitId != Guid.Empty)
            {
                restrictionUnit = ObjectContext.GetObject<StaffUnit>(RestrictionUnitId);
            }

            // Выбираем сотрудников подразделения
            IEnumerable<StaffEmployee> employees = StaffService.GetUnitEmployees(restrictionUnit, (restrictionUnit == null) ? true : false, false);

            // Если установлен фильтр состояний - применяем его
            if (SelectedEmployeeStatus != null)
                employees = employees.Where(t => t.Status == SelectedEmployeeStatus);
            // Если установлен флаг для отображения только "активных" сотрудников - применяем его
            else if (HideNotActive)
             employees = employees.Where(t => t.Status == StaffEmployeeStatus.Active);
            

            foreach (var item in employees)
            {
                Guid employeeId = ObjectContext.GetObjectRef(item).Id;
                ObjectCollection<StaffPicture> pictures = item.Pictures;

                this.staffControl1.StaffControlItems.Add(
                    new StaffControlItem(employeeId,
                        item.DisplayName,
                        (pictures.Count == 0) ? null : item.Pictures[0].Image,
                        item.PositionName, item.Phone));
            }
        }

        // Возвращает значение для ссылочного поля, если 
        internal object GetValue(string fieldName)
        {
            try
            {
                Guid idValue;
                if (Guid.TryParse(this.ControlValue.ToString(), out idValue))
                {
                    UserSession session = ObjectContext.GetService<UserSession>();
                    if (session != null)
                    {
                        CardData cardData = session.CardManager.GetCardData(RefStaff.ID);
                        SectionData sectionData = cardData.Sections[RefStaff.Employees.ID];
                        return sectionData.Fields.Contains(fieldName) && sectionData.RowExists(idValue) ? sectionData.GetRow(idValue)[fieldName] : null;
                    }
                }
            }
            catch { }

            return null;
        }

        // Обработка выбора пользователем сотрудника
        void staffControl1_SelectionChanged(Guid? employeeId)
        {
            if (employeeId.HasValue)
            {
                controlValue = employeeId;
            }
            else
            {
                controlValue = null;

            }
            ControlValueChanged(this, new EventArgs());
        }
    }
}
