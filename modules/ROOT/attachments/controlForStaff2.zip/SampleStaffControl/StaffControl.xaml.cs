﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace SampleStaffControl
{
    /// <summary>
    /// Interaction logic for StaffControl.xaml
    /// </summary>
    public partial class StaffControl : UserControl
    {
        public ObservableCollection<StaffControlItem> StaffControlItems { get; set; }

        public StaffControl()
        {
            StaffControlItems = new ObservableCollection<StaffControlItem>();
            InitializeComponent();

            this.StaffSelector.SelectionChanged += (s, e) =>
            {
                if (StaffSelector.SelectedIndex == -1)
                {
                    SelectionChanged(null);
                }
                else
                {
                    SelectionChanged((StaffSelector.SelectedItem as StaffControlItem).EmployeeId);
                }
            };
        }

        public event StaffSelectionChangedEventHandler SelectionChanged = delegate { };

        public bool SelectItem(Guid? employeeId)
        {
            if (!employeeId.HasValue)
            {
                StaffSelector.SelectedIndex = -1;
                return true;
            }
            else {
                StaffControlItem result = null;
                foreach (StaffControlItem item in StaffSelector.Items)
                {
                    if (item.EmployeeId == employeeId)
                    {
                        result = item;
                        break;
                    }
                }
                if (result == null)
                {
                    StaffSelector.SelectedIndex = -1;
                    return false;
                }
                else {
                    StaffSelector.SelectedItem = result;
                    return true;
                }
            }
            
        }
    }
    public delegate void StaffSelectionChangedEventHandler(Guid? employeeId);


    public class StaffControlItem
    {
        public Guid EmployeeId { get; private set; }
        public string EmployeeName { get; private set; }
        public ImageSource EmployeeImage { get; private set; }
        public string EmployeePosition { get; private set; }
        public string EmployeePhone { get; private set; }

        public StaffControlItem(Guid employeeId, string employeeName, System.Drawing.Image employeeImage, string employeePosition, string employeePhone)
        {
            this.EmployeeId = employeeId;
            this.EmployeeName = employeeName;
            this.EmployeeImage = Convert(employeeImage);
            this.EmployeePosition = employeePosition;
            this.EmployeePhone = employeePhone;
        }

        // Image -> BitmapSource
        private ImageSource Convert(System.Drawing.Image image)
        {
            if (image == null) image = Properties.Resources.Unknown_Person;

            BitmapSource bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                       (image as System.Drawing.Bitmap).GetHbitmap(),
                       IntPtr.Zero,
                       Int32Rect.Empty,
                       System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
            return bitmapSource;
        }
    }
}
