﻿using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.WinForms.Design.PropertyWrappers;
using System;
using System.ComponentModel;
using System.Drawing.Design;

namespace SampleStaffControl
{
    /// <summary>
    /// В классе перечисляем параметры элемента управления, отображаемые в его свойствах
    /// </summary>
    public class StaffControlWrapper : SpecialPropertyWrapper<StaffControlLayoutItem>
    {

        /// <summary>
        /// Параметр RestrictionUnitId определяет идентификатор подразделения, ограничивающего возможность выбора сотрудников
        /// В Category и DisplayName определяем категорию и название
        /// В TypeConverter указываем вспомогательный конвертер, который (для простоты выбора элемента из списка) 
        /// переводит ID подразделения в его название
        /// В Editor определяем собственный редактор для параметра элемента управления. Если для выбора параметра 
        /// не требуется специальной логики (например, простой выбор из готового списка), то данный атрибут можно не указывать
        /// </summary>
        [Category("Дополнительные настройки"), DisplayName("Подразделение"), Description("Будут выведены только сотрудники указанного подразделения и подчиненных подразделений")]
        [TypeConverter(typeof(UnitConverter))]
        [Editor(typeof(RestrictionUnitEditor), typeof(UITypeEditor))]
        public Guid RestrictionUnitId
        {
            get
            {
                return this.Item.RestrictionUnitId;
            }
            set
            {
                this.Item.RestrictionUnitId = value;
            }
        }
      
        [Category("Дополнительные настройки"), DisplayName("Состояние"), Description("Будут выведены только сотрудники с указанным состоянием")]
        [TypeConverter(typeof(StaffEmployeeStatusConverter))]
        public StaffEmployeeStatus? SelectedEmployeeStatus
        {
            get
            {
                return this.Item.SelectedEmployeeStatus;
            }
            set
            {
                this.Item.SelectedEmployeeStatus = value;
            }
        }
    }

}
