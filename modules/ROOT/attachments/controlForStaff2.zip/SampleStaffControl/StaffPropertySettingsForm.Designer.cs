﻿namespace SampleStaffControl
{
    partial class StaffPropertySettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hideNotActive = new DevExpress.XtraEditors.CheckEdit();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl)).BeginInit();
            this.layoutControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mainLayoutControlGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonsPanelControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hideNotActive.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            this.SuspendLayout();
            // 
            // layoutControl
            // 
            this.layoutControl.Controls.Add(this.hideNotActive);
            this.layoutControl.Size = new System.Drawing.Size(261, 143);
            this.layoutControl.Controls.SetChildIndex(this.buttonsPanelControl, 0);
            this.layoutControl.Controls.SetChildIndex(this.hideNotActive, 0);
            // 
            // mainLayoutControlGroup
            // 
            this.mainLayoutControlGroup.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1});
            this.mainLayoutControlGroup.Size = new System.Drawing.Size(261, 143);
            // 
            // buttonsPanelControl
            // 
            this.buttonsPanelControl.Location = new System.Drawing.Point(12, 107);
            this.buttonsPanelControl.Size = new System.Drawing.Size(237, 24);
            this.buttonsPanelControl.TabIndex = 4;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 95);
            this.layoutControlItem2.Size = new System.Drawing.Size(241, 28);
            // 
            // hideNotActive
            // 
            this.hideNotActive.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hideNotActive.EditValue = true;
            this.hideNotActive.Location = new System.Drawing.Point(12, 84);
            this.hideNotActive.Margin = new System.Windows.Forms.Padding(0);
            this.hideNotActive.Name = "hideNotActive";
            this.hideNotActive.Properties.Caption = "Скрывать неактивных сотрудников:";
            this.hideNotActive.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.hideNotActive.Size = new System.Drawing.Size(237, 19);
            this.hideNotActive.StyleController = this.layoutControl;
            this.hideNotActive.TabIndex = 3;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.hideNotActive;
            this.layoutControlItem1.CustomizationFormText = "layoutControlItem1";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 72);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(241, 23);
            this.layoutControlItem1.Text = "layoutControlItem1";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextToControlDistance = 0;
            this.layoutControlItem1.TextVisible = false;
            // 
            // StaffPropertySettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 143);
            this.Name = "StaffPropertySettingsForm";
            this.Text = "Свойства";
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl)).EndInit();
            this.layoutControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mainLayoutControlGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.buttonsPanelControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hideNotActive.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.CheckEdit hideNotActive;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
    }
}