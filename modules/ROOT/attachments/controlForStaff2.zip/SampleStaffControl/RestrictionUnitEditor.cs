﻿using DevExpress.XtraEditors;
using DocsVision.BackOffice.WinForms.Controls;
using DocsVision.Platform.CardHost;
using DocsVision.Platform.ObjectModel;
using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace SampleStaffControl
{
    // Реализация собственного редактора для свойства 
    class RestrictionUnitEditor : UITypeEditor
    {

        // Переопределяем метод вызываемый при изменении значения настройки
        public override Object EditValue(ITypeDescriptorContext context, IServiceProvider provider, Object value)
        {
            if (context != null && provider != null && context.Instance is StaffControlWrapper)
            {
                IWindowsFormsEditorService svc = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));
                ListBoxControl listBox = new ListBoxControl();

                // Добавляем возможные значения настройки
                listBox.Items.Add(new ComboItem<bool>("Пусто", false));
                listBox.Items.Add(new ComboItem<bool>("Выбрать", true));
                listBox.Tag = svc;
                listBox.Click += (s, e) =>
                {
                    svc.CloseDropDown();
                };

                svc.DropDownControl(listBox);

                StaffControlWrapper wrapper = (StaffControlWrapper)context.Instance;
                
                // Если пользователь указал, что требуется выбирать подразделение, то выводим окно выбора
                if ((listBox.SelectedItem as ComboItem<bool>).Key)
                {
                    ICardHost cardHost = StaticObjectContext.Current.GetService<ICardHost>();
                    object selectedValue = cardHost.SelectFromCard(DocsVision.BackOffice.CardLib.CardDefs.RefStaff.ID, "Выберите подразделение", new string[] { DocsVision.BackOffice.CardLib.CardDefs.RefStaff.Units.ID.ToString() });
                    if (selectedValue is string && !string.IsNullOrEmpty((string)selectedValue))
                    {
                        wrapper.RestrictionUnitId = new Guid((string)selectedValue);
                    }
                }
                else
                {
                    wrapper.RestrictionUnitId = Guid.Empty;
                }
            }
            
            return base.EditValue(context, provider, value);
        }

        public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
        {
            return context != null ? UITypeEditorEditStyle.DropDown : base.GetEditStyle(context);
        }
    }
}
