﻿using DocsVision.BackOffice.CardLib.CardDefs;
using DocsVision.BackOffice.WinForms.Design;
using DocsVision.BackOffice.WinForms.Design.LayoutItems;
using DocsVision.Platform.Data.Metadata.CardModel;
using System;

namespace SampleStaffControl
{
    /// <summary>
    /// Форма для основного окна свойств элемента управления. 
    /// Форма открывается при выборе команды свойства из контекстного меню элемента управления
    /// Форма должна наследоваться от DocsVision.BackOffice.WinForms.Design.PropertySettingsForm
    /// </summary>
    public partial class StaffPropertySettingsForm : PropertySettingsForm
    {
        public StaffPropertySettingsForm()
        {
            InitializeComponent();
        }

        // Обязательный конструктор
        public StaffPropertySettingsForm(IServiceProvider serviceProvider, DesignManager designManager, ICustomPropertyItem propertyItem)
            : base(serviceProvider, designManager, propertyItem)
        {
            InitializeComponent();
        }
        /// <summary>
        /// Определяет возможность использования поля в качестве источника данных.
        /// Неподдерживаемые поля недоступны для выбора в качестве источника
        /// </summary>
        protected override bool IsSectionFieldSupported(SectionField sectionField)
        {
            // Поддерживается только Справочник сотрудников - секция Сотрудники
            return sectionField.LinkedCardTypeId == RefStaff.ID && sectionField.LinkedSectionId == RefStaff.Employees.ID;
        }


        /// <summary>
        /// Загрузка значений настроек
        /// </summary>
        protected override void LoadPropertyAttributes()
        {
            base.LoadPropertyAttributes();

            if (this.PropertyItem != null)
            {
                hideNotActive.Checked = ((StaffControlLayoutItem)this.PropertyItem).HideNotActive;
            }
        }

        /// <summary>
        /// Сохранение значений настроек
        /// </summary>
        protected override void UpdatePropertyAttributes()
        {
            base.UpdatePropertyAttributes();

            if (this.PropertyItem != null)
            {
                ((StaffControlLayoutItem)this.PropertyItem).HideNotActive = hideNotActive.Checked;
            }
        }
    }
}
