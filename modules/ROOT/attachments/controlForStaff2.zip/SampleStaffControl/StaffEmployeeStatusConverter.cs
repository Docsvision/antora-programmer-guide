﻿using DocsVision.BackOffice.ObjectModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SampleStaffControl
{
    public class StaffEmployeeStatusConverter : TypeConverter
    {
        public static Dictionary<StaffEmployeeStatus, string> StatusNames = new Dictionary<StaffEmployeeStatus, string>()
        {
            {StaffEmployeeStatus.Absent, "Отсутствует"},
            {StaffEmployeeStatus.Active, "Активен"},
            {StaffEmployeeStatus.BusinessTrip, "В командировке"},
            {StaffEmployeeStatus.Discharged, "Уволен"},
            {StaffEmployeeStatus.DischargedNoRestoration, "Уволен без возможности восстановления"},
            {StaffEmployeeStatus.Sick, "Болен"},
            {StaffEmployeeStatus.Transfered, "Переведен"},
            {StaffEmployeeStatus.Vacation, "В отпуске"}
        };


        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(System.Enum.GetValues(typeof(StaffEmployeeStatus)));
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            string strValue = (string)value;

            if (StatusNames.ContainsValue(strValue)) return StatusNames.First(t => t.Value.Equals(strValue)).Key;
            else return null;
        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (value == null) return string.Empty;

            if (StatusNames.ContainsKey((StaffEmployeeStatus)value))
                return StatusNames[(StaffEmployeeStatus)value];

            return base.ConvertTo(value, destinationType);
        }
    }
}
