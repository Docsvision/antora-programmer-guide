﻿using DocsVision.BackOffice.WinForms.Design.PropertyWrappers;
using System;
using System.ComponentModel;
using System.Globalization;

namespace DevelopmentControl
{
    public class RealWrapper : SpecialPropertyWrapper<RealLayoutItem>
    {

        [Category("Дополнительные настройки"), DisplayName("Все подразделения"), Description("Выводить все подразделения или только первый уровень")]
        [TypeConverter(typeof(BooleanTypeConverter))]
        public bool Hierarchy
        {
            get
            {
                return this.Item.Hierarchy;
            }
            set
            {
                this.Item.Hierarchy = value;
            }
        }

    }

    internal sealed class BooleanTypeConverter : BooleanConverter
    {

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destType)
        {
            return (bool)value ? "Да" : "Нет";
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            return string.Compare((string)value, "Да", StringComparison.OrdinalIgnoreCase) == 0;
        }

    }
}
