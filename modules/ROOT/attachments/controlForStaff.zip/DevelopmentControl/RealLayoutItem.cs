﻿using DevExpress.Utils.Serializing;
using DocsVision.BackOffice.ObjectModel;
using DocsVision.BackOffice.WinForms.Design.LayoutItems;
using DocsVision.Platform.Data.Metadata.CardModel;
using System.Windows.Forms;

namespace DevelopmentControl
{
    public class RealLayoutItem : FixedLayoutControlItem<RealPropertyControl>
    {
        private bool hierarchy;

        // Возвращает название элемента управления, отображаемое в Конструкторе разметок
        public override string ItemTypeName
        {
            get
            {
                return "Собственный элемент управления";
            }
        }

        // Возвращает иконку для элемента управления, отображаемую в Конструкторе разметок 
        public override System.Drawing.Image CustomizationImage
        {
            get
            {
                return DevelopmentControl.Properties.Resources.ButtonIcon.ToBitmap();
            }
        }

        // Возвращает тип данные элемента управления, который используется при преобразовании для элемента управления его значения по умолчанию 
        public override LayoutsPropertyType PropertyType
        {
            // В данном случае - ссылка на подразделения
            get { return LayoutsPropertyType.DepartmentReference; }
        }

        // Возвращает список типов полей, с которыми работает элемент управления
        //public override FieldType[] GetSupportedFieldTypes()
        //{
        //    return new FieldType[]
        //    {
        //         // В данном случае - ссылочное поле
        //        FieldType.RefId
        //    };
        //}

        // При установке элемента управления передаем настройки в него
        public override Control Control
        {
            get
            {
                return base.Control;
            }
            set
            {
                base.Control = value;
                if (value != null)
                {
                    this.PropertyControl.Hierarchy = hierarchy;
                }
            }
        }


        // Обеспечение передачи значения свойства в класс элемента управления
        [XtraSerializableProperty]
        public bool Hierarchy
        {
            get
            {
                if (base.PropertyControl != null)
                    return base.PropertyControl.Hierarchy;

                return hierarchy;
            }
            set
            {
                if (this.PropertyControl != null)
                    this.PropertyControl.Hierarchy = value;
                hierarchy = value;
            }
        }
    }
}
