﻿using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DocsVision.BackOffice.ObjectModel.Services;
using DocsVision.BackOffice.WinForms.Design.PropertyControls;
using DocsVision.Platform.ObjectModel;
using System;
using System.Windows.Forms;

namespace DevelopmentControl
{
    public partial class RealPropertyControl : XtraUserControl, IPropertyControl
    {
        // Сервис для работы со Справочником сотрудников
        private IStaffService staffService;

        public RealPropertyControl()
        {
            this.InitializeComponent();
        }

        #region Реализация интерфейса IPropertyControl

        // Если false, то только чтение
        public bool AllowEdit
        {
            get;
            set;
        }

        // Собственная реализация метода Commit - может юыть вызван разработчиком, после присвоения значения элементу управления
        public void Commit()
        {
        }

        // Значение элемента управления
        public object ControlValue
        {
            get;
            set;
        }

        // Событие, вызываемое при изменении значения элемента управления
        public event EventHandler ControlValueChanged;

        // Возвращает значение по умолчанию
        public object GetDefaultControlValue()
        {
            return null;
        }

        // Реализация метода копирования значения элемента управления
        public object GetValueCopy()
        {
            return this.ControlValue;
        }

        // Показывать Border у элемента управления
        public bool ShowBorder
        {
            get;
            set;
        }

        // 
        public bool Signed
        {
            get;
            set;
        }

        // Тест подсказки
        public string ToolTip
        {
            get;
            set;
        }

        private ObjectContext objectContext;
        // Контекст объектов - присваивается автоматически после загрузки элемента управления
        public ObjectContext ObjectContext
        {
            get
            {
                return objectContext;
            }
            set
            {
                objectContext = value;
                LoadData();
            }
        }
        #endregion

        // Отображать в списке все подразделения или только подразделения верхнего уровня
        public bool Hierarchy
        {
            get;
            set;
        }

        // Загрузка данных из Справочника сотрудников в элемент управления
        public void LoadData()
        {
            // Если контекст объектов не был передан, то загрузить данные не получится
            if (ObjectContext == null) return;

            staffService = ObjectContext.GetService<IStaffService>();
            ComboBoxItemCollection coll = staffBox.Properties.Items;

            coll.BeginUpdate();
            foreach (var item in staffService.GetUnits(null, true, Hierarchy))
            {
                coll.Add(new StaffBoxItem(ObjectContext.GetObjectRef(item).Id, item.Name));
            }
            coll.EndUpdate();

        }

        // Выбор элемента управления
        private void staffBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (staffBox.SelectedIndex == -1) ControlValue = null;
            else ControlValue = (staffBox.SelectedItem as StaffBoxItem).Id;

            ControlValueChanged(this, e);
        }
    }

}