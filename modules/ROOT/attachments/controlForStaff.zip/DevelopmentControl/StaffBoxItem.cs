﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevelopmentControl
{
    public class StaffBoxItem
    {
        public Guid Id { get; private set; }
        public string DisplayName { get; private set; }

        public StaffBoxItem(Guid id, string displayName)
        {
            this.Id = id;
            this.DisplayName = displayName;
        }

        public override string ToString()
        {
            return string.IsNullOrWhiteSpace(this.DisplayName) ? base.ToString() : DisplayName;
        }
    }
}
